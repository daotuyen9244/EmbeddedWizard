void __aeabi_assert( int condition )
{
  if ( ! condition )
    while( 1 );
}

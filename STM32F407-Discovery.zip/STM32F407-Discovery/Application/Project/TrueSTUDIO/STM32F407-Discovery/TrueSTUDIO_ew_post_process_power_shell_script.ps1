﻿######################### CHECK PRO VERSION ############################
$executingScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
$Path = Join-Path $executingScriptDirectory "../../../../PlatformPackage/RTE/ewcolor.c"

$UseLibaries = 1
if (Test-Path $path) 
{
    $UseLibaries = 0
}

######################### PARSE EWFILES.INC ############################
$executingScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
$Path = Join-Path $executingScriptDirectory "../../../GeneratedCode/ewfiles.inc"

# Get color format
$ColorFormat = 0
If (Select-String -Path $Path -Pattern "RGBA8888" -SimpleMatch -Quiet) 
{
    $ColorFormat = 1
}
If (Select-String -Path $Path -Pattern "RGBA4444" -SimpleMatch -Quiet) 
{
    $ColorFormat = 2
}
If (Select-String -Path $Path -Pattern "RGB888" -SimpleMatch -Quiet)  
{
    $ColorFormat = 3
}
If (Select-String -Path $Path -Pattern "RGB565" -SimpleMatch -Quiet) 
{
    $ColorFormat = 4
}
If (Select-String -Path $Path -Pattern "LumA44" -SimpleMatch -Quiet) 
{
    $ColorFormat = 5
}
If (Select-String -Path $Path -Pattern "Index8" -SimpleMatch -Quiet) 
{
    $ColorFormat = 6
}

# Get screen orientation
$ScreenOrientation = 0
If (Select-String -Path $Path -Pattern "90" -SimpleMatch -Quiet) 
{
    $ScreenOrientation = 90
}

If (Select-String -Path $Path -Pattern "180" -SimpleMatch -Quiet) 
{
    $ScreenOrientation = 180
}

If (Select-String -Path $Path -Pattern "270" -SimpleMatch -Quiet) 
{
    $ScreenOrientation = 270
}

######################### EDIT TRUESTUDIO PROJECT ############################
# Open file
$executingScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
$Path = Join-Path $executingScriptDirectory ".cproject"

# Edit text file content for XML add on
(Get-Content $Path).replace('"&quot;${ProjDirPath}/../../../../PlatformPackage/RTE&quot;"', '"../../../../PlatformPackage/RTE"') | Set-Content $Path
(Get-Content $Path).replace('"&quot;${ProjDirPath}/../../../../PlatformPackage/RGBA8888&quot;"', '"../../../../PlatformPackage/RGBA8888"') | Set-Content $Path
(Get-Content $Path).replace('"&quot;${ProjDirPath}/../../../../PlatformPackage/RGBA4444&quot;"', '"../../../../PlatformPackage/RGBA4444"') | Set-Content $Path
(Get-Content $Path).replace('"&quot;${ProjDirPath}/../../../../PlatformPackage/RGB888&quot;"', '"../../../../PlatformPackage/RGB888"') | Set-Content $Path
(Get-Content $Path).replace('"&quot;${ProjDirPath}/../../../../PlatformPackage/RGB565&quot;"', '"../../../../PlatformPackage/RGB565"') | Set-Content $Path
(Get-Content $Path).replace('"&quot;${ProjDirPath}/../../../../PlatformPackage/LumA44&quot;"', '"../../../../PlatformPackage/LumA44"') | Set-Content $Path
(Get-Content $Path).replace('"&quot;${ProjDirPath}/../../../../PlatformPackage/Index8&quot;"', '"../../../../PlatformPackage/Index8"') | Set-Content $Path

$xml = [xml](get-content $Path)
$xml.Load($Path)

######################### PATHS ############################
# Select include path node
$target = ((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Include path"})

# Delete all color format dependents include paths if them exist
$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Include path"}).listOptionValue|where {$_.value -eq "../../../../PlatformPackage/RTE"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Include path"}).listOptionValue|where {$_.value -eq ""})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Include path"}).listOptionValue|where {$_.value -eq "../../../../PlatformPackage/RGBA8888"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Include path"}).listOptionValue|where {$_.value -eq "../../../../PlatformPackage/RGBA4444"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Include path"}).listOptionValue|where {$_.value -eq "../../../../PlatformPackage/RGB888"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Include path"}).listOptionValue|where {$_.value -eq "../../../../PlatformPackage/RGB565"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Include path"}).listOptionValue|where {$_.value -eq "../../../../PlatformPackage/LumA44"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Include path"}).listOptionValue|where {$_.value -eq "../../../../PlatformPackage/Index8"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

# Insert new necessary include paths
$addElem = $xml.CreateElement("listOptionValue")
$addAtt = $xml.CreateAttribute("builtIn")
$addAtt.Value = "false"
$addElem.Attributes.Append($addAtt) | Out-Null
$addAtt = $xml.CreateAttribute("value")
$addAtt.Value = "&quot;`${ProjDirPath}/../../../../PlatformPackage/RTE&quot;"
$addElem.Attributes.Append($addAtt) | Out-Null
$target.AppendChild($addElem) | Out-Null

$addElem = $xml.CreateElement("listOptionValue")
$addAtt = $xml.CreateAttribute("builtIn")
$addAtt.Value = "false"
$addElem.Attributes.Append($addAtt) | Out-Null
$addAtt = $xml.CreateAttribute("value") 
switch($ColorFormat)
{
    1 {$addAtt.Value = "&quot;`${ProjDirPath}/../../../../PlatformPackage/RGBA8888&quot;"}
    2 {$addAtt.Value = "&quot;`${ProjDirPath}/../../../../PlatformPackage/RGBA4444&quot;"}
    3 {$addAtt.Value = "&quot;`${ProjDirPath}/../../../../PlatformPackage/RGB888&quot;"}
    4 {$addAtt.Value = "&quot;`${ProjDirPath}/../../../../PlatformPackage/RGB565&quot;"}
    5 {$addAtt.Value = "&quot;`${ProjDirPath}/../../../../PlatformPackage/LumA44&quot;"}
    6 {$addAtt.Value = "&quot;`${ProjDirPath}/../../../../PlatformPackage/Index8&quot;"}
    default {Write-Host Failed to change color format path!}
}
$addElem.Attributes.Append($addAtt) | Out-Null
$target.AppendChild($addElem) | Out-Null

######################### SYMBOLS ############################
# Select symbol node
$target = ((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Defined symbols"})

# Delete all color format dependents symbols
$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Defined symbols"}).listOptionValue|where {$_.value -eq ""})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Defined symbols"}).listOptionValue|where {$_.value -eq "EW_FRAME_BUFFER_COLOR_FORMAT=EW_FRAME_BUFFER_COLOR_FORMAT_RGBA8888"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Defined symbols"}).listOptionValue|where {$_.value -eq "EW_FRAME_BUFFER_COLOR_FORMAT=EW_FRAME_BUFFER_COLOR_FORMAT_RGBA4444"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Defined symbols"}).listOptionValue|where {$_.value -eq "EW_FRAME_BUFFER_COLOR_FORMAT=EW_FRAME_BUFFER_COLOR_FORMAT_RGB888"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Defined symbols"}).listOptionValue|where {$_.value -eq "EW_FRAME_BUFFER_COLOR_FORMAT=EW_FRAME_BUFFER_COLOR_FORMAT_RGB565"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Defined symbols"}).listOptionValue|where {$_.value -eq "EW_FRAME_BUFFER_COLOR_FORMAT=EW_FRAME_BUFFER_COLOR_FORMAT_LumA44"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Defined symbols"}).listOptionValue|where {$_.value -eq "EW_FRAME_BUFFER_COLOR_FORMAT=EW_FRAME_BUFFER_COLOR_FORMAT_Index8"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

# Insert new color format dependents symbols
$addElem = $xml.CreateElement("listOptionValue")
$addAtt = $xml.CreateAttribute("builtIn")
$addAtt.Value = "false"
$addElem.Attributes.Append($addAtt) | Out-Null
$addAtt = $xml.CreateAttribute("value")
switch($ColorFormat)
{
    1 {$addAtt.Value = "EW_FRAME_BUFFER_COLOR_FORMAT=EW_FRAME_BUFFER_COLOR_FORMAT_RGBA8888"}
    2 {$addAtt.Value = "EW_FRAME_BUFFER_COLOR_FORMAT=EW_FRAME_BUFFER_COLOR_FORMAT_RGBA4444"}
    3 {$addAtt.Value = "EW_FRAME_BUFFER_COLOR_FORMAT=EW_FRAME_BUFFER_COLOR_FORMAT_RGB888"}
    4 {$addAtt.Value = "EW_FRAME_BUFFER_COLOR_FORMAT=EW_FRAME_BUFFER_COLOR_FORMAT_RGB565"}
    5 {$addAtt.Value = "EW_FRAME_BUFFER_COLOR_FORMAT=EW_FRAME_BUFFER_COLOR_FORMAT_LumA44"}
    6 {$addAtt.Value = "EW_FRAME_BUFFER_COLOR_FORMAT=EW_FRAME_BUFFER_COLOR_FORMAT_Index8"}
    default {Write-Host Failed to change color format symbol!}
}
$addElem.Attributes.Append($addAtt) | Out-Null
$target.AppendChild($addElem) | Out-Null

# Select symbol node
$target = ((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Defined symbols"})

# Delete all color format dependents symbols
$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Defined symbols"}).listOptionValue|where {$_.value -eq ""})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Defined symbols"}).listOptionValue|where {$_.value -eq "EW_SURFACE_ROTATION=0"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Defined symbols"}).listOptionValue|where {$_.value -eq "EW_SURFACE_ROTATION=90"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Defined symbols"}).listOptionValue|where {$_.value -eq "EW_SURFACE_ROTATION=180"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Compiler"}).option|where {$_.name -eq "Defined symbols"}).listOptionValue|where {$_.value -eq "EW_SURFACE_ROTATION=270"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

# Insert new color format dependents symbols
$addElem = $xml.CreateElement("listOptionValue")
$addAtt = $xml.CreateAttribute("builtIn")
$addAtt.Value = "false"
$addElem.Attributes.Append($addAtt) | Out-Null
$addAtt = $xml.CreateAttribute("value")
switch($ScreenOrientation)
{
    0 {$addAtt.Value = "EW_SURFACE_ROTATION=0"}
    90 {$addAtt.Value = "EW_SURFACE_ROTATION=90"}
    180 {$addAtt.Value = "EW_SURFACE_ROTATION=180"}
    270 {$addAtt.Value = "EW_SURFACE_ROTATION=270"}
    default {Write-Host Failed to change libary!}
}
$addElem.Attributes.Append($addAtt) | Out-Null
$target.AppendChild($addElem) | Out-Null

######################### LIBARY PATHS ############################
# Select libary path node
$target = ((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Linker"}).option|where {$_.name -eq "Library search path"})

# Delete rte path
$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Linker"}).option|where {$_.name -eq "Library search path"}).listOptionValue|where {$_.value -eq "../../../../PlatformPackage/RTE"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

# Delete all color format dependents libary paths if them exist
$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Linker"}).option|where {$_.name -eq "Library search path"}).listOptionValue|where {$_.value -eq ""})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Linker"}).option|where {$_.name -eq "Library search path"}).listOptionValue|where {$_.value -eq "../../../../PlatformPackage/RGBA8888"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Linker"}).option|where {$_.name -eq "Library search path"}).listOptionValue|where {$_.value -eq "../../../../PlatformPackage/RGBA4444"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Linker"}).option|where {$_.name -eq "Library search path"}).listOptionValue|where {$_.value -eq "../../../../PlatformPackage/RGB888"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Linker"}).option|where {$_.name -eq "Library search path"}).listOptionValue|where {$_.value -eq "../../../../PlatformPackage/RGB565"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Linker"}).option|where {$_.name -eq "Library search path"}).listOptionValue|where {$_.value -eq "../../../../PlatformPackage/LumA44"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Linker"}).option|where {$_.name -eq "Library search path"}).listOptionValue|where {$_.value -eq "../../../../PlatformPackage/Index8"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

if($UseLibaries)
{
    # Insert new libary path
    $addElem = $xml.CreateElement("listOptionValue")
    $addAtt = $xml.CreateAttribute("builtIn")
    $addAtt.Value = "false"
    $addElem.Attributes.Append($addAtt) | Out-Null
    $addAtt = $xml.CreateAttribute("value")
    $addAtt.Value = "&quot;`${ProjDirPath}/../../../../PlatformPackage/RTE&quot;"
    $addElem.Attributes.Append($addAtt) | Out-Null
    $target.AppendChild($addElem) | Out-Null

    $addElem = $xml.CreateElement("listOptionValue")
    $addAtt = $xml.CreateAttribute("builtIn")
    $addAtt.Value = "false"
    $addElem.Attributes.Append($addAtt) | Out-Null
    $addAtt = $xml.CreateAttribute("value")
    switch($ColorFormat)
    {
        1 {$addAtt.Value = "&quot;`${ProjDirPath}/../../../../PlatformPackage/RGBA8888&quot;"}
        2 {$addAtt.Value = "&quot;`${ProjDirPath}/../../../../PlatformPackage/RGBA4444&quot;"}
        3 {$addAtt.Value = "&quot;`${ProjDirPath}/../../../../PlatformPackage/RGB888&quot;"}
        4 {$addAtt.Value = "&quot;`${ProjDirPath}/../../../../PlatformPackage/RGB565&quot;"}
        5 {$addAtt.Value = "&quot;`${ProjDirPath}/../../../../PlatformPackage/LumA44&quot;"}
        6 {$addAtt.Value = "&quot;`${ProjDirPath}/../../../../PlatformPackage/Index8&quot;"}
        default {Write-Host Failed to change libary path!}
    }
    $addElem.Attributes.Append($addAtt) | Out-Null
    $target.AppendChild($addElem) | Out-Null
}

######################### LIBARIES ############################
# Select libary node
$target = ((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Linker"}).option|where {$_.name -eq "Libraries"})

# Delete rte include
$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Linker"}).option|where {$_.name -eq "Libraries"}).listOptionValue|where {$_.value -eq "ewrte-m4-gcc"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

# Delete all libary includes if them exist
$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Linker"}).option|where {$_.name -eq "Libraries"}).listOptionValue|where {$_.value -eq ""})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Linker"}).option|where {$_.name -eq "Libraries"}).listOptionValue|where {$_.value -eq "ewgfx-m4-gcc"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Linker"}).option|where {$_.name -eq "Libraries"}).listOptionValue|where {$_.value -eq "ewgfx-m4-r90-gcc"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Linker"}).option|where {$_.name -eq "Libraries"}).listOptionValue|where {$_.value -eq "ewgfx-m4-r180-gcc"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

$DeleteNode = (((((((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).folderInfo.toolChain)|where {$_.name -eq "Atollic ARM Tools"}).tool|where {$_.name -eq "C Linker"}).option|where {$_.name -eq "Libraries"}).listOptionValue|where {$_.value -eq "ewgfx-m4-r270-gcc"})
if($DeleteNode) { $target.RemoveChild($DeleteNode) | Out-Null }

if($UseLibaries)
{
    # Insert new libary include
    $addElem = $xml.CreateElement("listOptionValue")
    $addAtt = $xml.CreateAttribute("builtIn")
    $addAtt.Value = "false"
    $addElem.Attributes.Append($addAtt) | Out-Null
    $addAtt = $xml.CreateAttribute("value")
    switch($ScreenOrientation)
    {
        0 {$addAtt.Value = "ewgfx-m4-gcc"}
        90 {$addAtt.Value = "ewgfx-m4-r90-gcc"}
        180 {$addAtt.Value = "ewgfx-m4-r180-gcc"}
        270 {$addAtt.Value = "ewgfx-m4-r270-gcc"}
        default {Write-Host Failed to change libary!}
    }
    $addElem.Attributes.Append($addAtt) | Out-Null
    $target.AppendChild($addElem) | Out-Null

    # Insert new libary include
    $addElem = $xml.CreateElement("listOptionValue")
    $addAtt = $xml.CreateAttribute("builtIn")
    $addAtt.Value = "false"
    $addElem.Attributes.Append($addAtt) | Out-Null
    $addAtt = $xml.CreateAttribute("value")
    $addAtt.Value = "ewrte-m4-gcc"
    $addElem.Attributes.Append($addAtt) | Out-Null
    $target.AppendChild($addElem) | Out-Null
}

######################### EXCLUDES FROM BUILD ############################
$target = (((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).sourceEntries.entry).excluding

$CurrentColorFormat = ""
$NewColorFormat = ""

If ($target -notmatch 'RGBA8888') { $CurrentColorFormat = "RGBA8888" }
If ($target -notmatch 'RGBA4444') { $CurrentColorFormat = "RGBA4444" }
If ($target -notmatch 'RGB888') { $CurrentColorFormat = "RGB888" }
If ($target -notmatch 'RGB565') { $CurrentColorFormat = "RGB565" }
If ($target -notmatch 'LumA44') { $CurrentColorFormat = "LumA44" }
If ($target -notmatch 'Index8') { $CurrentColorFormat = "Index8" }

switch($ColorFormat)
{
    1 {$NewColorFormat = "RGBA8888"}
    2 {$NewColorFormat = "RGBA4444"}
    3 {$NewColorFormat = "RGB888"}
    4 {$NewColorFormat = "RGB565"}
    5 {$NewColorFormat = "LumA44"}
    6 {$NewColorFormat = "Index8"}
    default {Write-Host Failed to configure exclude paths!}
}

if($CurrentColorFormat -ne $NewColorFormat)
{
    $Newtarget = $target -replace $NewColorFormat, $CurrentColorFormat
    (((($xml.cproject.storageModule.cconfiguration|where {$_.id -eq "com.atollic.truestudio.exe.debug.1984525199"}).storageModule|where {$_.moduleId -eq "cdtBuildSystem"}).configuration|where {$_.name -eq "BUILD"}).sourceEntries.entry).excluding = $Newtarget
}

# Save and close file
$xml.Save($Path)

# Adapt ampersand
(get-content $Path) | foreach-object {$_ -replace "amp;quot;", "quot;"} | set-content $Path

/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is delivered "as is" and shows the usage of other software
* components. It is provided as an example software which is intended to be
* modified and extended according to particular requirements.
*
* TARA Systems hereby disclaims all warranties and conditions with regard to the
* software, including all implied warranties and conditions of merchantability
* and non-infringement of any third party IPR or other rights which may result
* from the use or the inability to use the software.
*
********************************************************************************
*
* DESCRIPTION:
*   This file contains the necessary initialization of the XPT2046 (or ADS7843)
*   touch controller and the necessary function to read the current touch
*   position.
*   The data transfer is done by using the hardware SPI controller.
*
*   This driver assumes the following layout of the interface:
*   SPI2:
*     MISO - PC2
*     MOSI - PC3
*     SCK  - PB10
*   Control lines:
*     /CS  - PB14 (NSS) => chip select, low active
*     INT  - PC13       => (PENIRQ) touch detected, low active
*
*   This module is just a template - adapt pin configuration and timing (!)
*   according your hardware layout and hardware constraints.
*   Adjust device parameters, initialization and filtering of the touch
*   coordinates according your touch screen and your needs.
*
*******************************************************************************/

#ifndef XPT2046_SPI_H
#define XPT2046_SPI_H


#ifdef __cplusplus
  extern "C"
  {
#endif

typedef struct
{
  uint16_t TouchDetected;
  uint16_t X;
  uint16_t Y;
  uint16_t Z;
}TS_StateTypeDef;


/*******************************************************************************
* FUNCTION:
*   XPT2046_Init
*
* DESCRIPTION:
*   The function initializes the SPI hardware and all necessary GPIO in order
*   to intialize the connected touch controller.
*
* ARGUMENTS:
*   aW       - Width of the touch area in pixel.
*   aH       - Height of the touch area in pixel.
*
* RETURN VALUE:
*   If successful, returns != 0.
*
*******************************************************************************/
int XPT2046_Init
(
  uint16_t                    aW,
  uint16_t                    aH
);


/*******************************************************************************
* FUNCTION:
*   XPT2046_GetTouchState
*
* DESCRIPTION:
*   The function returns the current touch state and touch position.
*
* ARGUMENTS:
*   aState   - Pointer to structure to return state and position.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void XPT2046_GetTouchState
(
  TS_StateTypeDef*            aState
);


#ifdef __cplusplus
}
#endif

#endif /* XPT2046_SPI_H */


/* msy */

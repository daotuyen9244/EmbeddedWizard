/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is delivered "as is" and shows the usage of other software
* components. It is provided as an example software which is intended to be
* modified and extended according to particular requirements.
*
* TARA Systems hereby disclaims all warranties and conditions with regard to the
* software, including all implied warranties and conditions of merchantability
* and non-infringement of any third party IPR or other rights which may result
* from the use or the inability to use the software.
*
********************************************************************************
*
* DESCRIPTION:
*   This file contains the necessary initialization of the SSD2119 display
*   controller and the necessary function to update a rectangular area of the
*   screen from an Embedded Wizard UI application.
*   The data transfer is done by using the hardware FSMC controller via the
*   16bit 8080 interface. The color format of the display is RGB565.
*
*   This driver assumes the following layout of the interface:
*   Data lines D0...D15 (FSMC):
*     D0   - PD14
*     D1   - PD15
*     D2   - PD0
*     D3   - PD1
*     D4   - PE7
*     D5   - PE8
*     D6   - PE9
*     D7   - PE10
*     D8   - PE11
*     D9   - PE12
*     D10  - PE13
*     D11  - PE14
*     D12  - PE15
*     D13  - PD8
*     D14  - PD9
*     D15  - PD10
*   Control lines (FSCM):
*     /CS  - PD7   (FSMC_NE1) => chip select, low active
*     /RD  - PD4   (FSMC_NOE) => read access, low active
*     /WR  - PD5   (FSMC_NWE) => write access, low active
*     DC   - PE3   (A19)      => register select (data/command)
*   Additional control lines:
*     /RST - PD3              => reset of LCD module, low active
*     BL   - PD13             => backlight
*
*   This module is just a template - adapt pin configuration and timing (!)
*   according your hardware layout and hardware constraints.
*   Adjust device parameters, initialization and gamma correction values
*   according your display and your needs.
*   This driver was tested on a STM32F4DIS-LCD (DM-LCD35RT) display module
*   (3,5" TFT 320x240).
*
*******************************************************************************/

#include "stm32f4xx_hal.h"

#include "ssd2119_16bit_fsmc.h"

/* LCD reset pin */
#define LCD_RESET_PIN                   GPIO_PIN_3
#define LCD_RESET_GPIO_PORT             GPIOD
#define LCD_RESET_GPIO_CLK_ENABLE()     __HAL_RCC_GPIOD_CLK_ENABLE()
#define LCD_RESET_GPIO_CLK_DISABLE()    __HAL_RCC_GPIOD_CLK_DISABLE()

/* backlight control pin */
#define LCD_BL_CTRL_PIN                 GPIO_PIN_13
#define LCD_BL_CTRL_GPIO_PORT           GPIOD
#define LCD_BL_CTRL_GPIO_CLK_ENABLE()   __HAL_RCC_GPIOD_CLK_ENABLE()
#define LCD_BL_CTRL_GPIO_CLK_DISABLE()  __HAL_RCC_GPIOD_CLK_DISABLE()

/* FSMC addresses for command and data port of SSD2119 */
#define SSD2119_Cmnd (__IO uint16_t*)((uint32_t)0x60000000)
#define SSD2119_Data (__IO uint16_t*)((uint32_t)0x60100000)

/* display specific settings */
#define DISPLAY_PIXEL_WIDTH             ((uint16_t)320)
#define DISPLAY_PIXEL_HEIGHT            ((uint16_t)240)

/* SSD2119 commands (from SSD2119 datasheet) */
#define SSD2119_DEVICE_CODE_READ_REG    0x00
#define SSD2119_OSC_START_REG           0x00
#define SSD2119_OUTPUT_CTRL_REG         0x01
#define SSD2119_LCD_DRIVE_AC_CTRL_REG   0x02
#define SSD2119_PWR_CTRL_1_REG          0x03
#define SSD2119_DISPLAY_CTRL_REG        0x07
#define SSD2119_FRAME_CYCLE_CTRL_REG    0x0B
#define SSD2119_PWR_CTRL_2_REG          0x0C
#define SSD2119_PWR_CTRL_3_REG          0x0D
#define SSD2119_PWR_CTRL_4_REG          0x0E
#define SSD2119_GATE_SCAN_START_REG     0x0F
#define SSD2119_SLEEP_MODE_1_REG        0x10
#define SSD2119_ENTRY_MODE_REG          0x11
#define SSD2119_SLEEP_MODE_2_REG        0x12
#define SSD2119_GEN_IF_CTRL_REG         0x15
#define SSD2119_PWR_CTRL_5_REG          0x1E
#define SSD2119_RAM_DATA_REG            0x22
#define SSD2119_FRAME_FREQ_REG          0x25
#define SSD2119_ANALOG_SET_REG          0x26
#define SSD2119_VCOM_OTP_1_REG          0x28
#define SSD2119_VCOM_OTP_2_REG          0x29
#define SSD2119_GAMMA_CTRL_1_REG        0x30
#define SSD2119_GAMMA_CTRL_2_REG        0x31
#define SSD2119_GAMMA_CTRL_3_REG        0x32
#define SSD2119_GAMMA_CTRL_4_REG        0x33
#define SSD2119_GAMMA_CTRL_5_REG        0x34
#define SSD2119_GAMMA_CTRL_6_REG        0x35
#define SSD2119_GAMMA_CTRL_7_REG        0x36
#define SSD2119_GAMMA_CTRL_8_REG        0x37
#define SSD2119_GAMMA_CTRL_9_REG        0x3A
#define SSD2119_GAMMA_CTRL_10_REG       0x3B
#define SSD2119_V_RAM_POS_REG           0x44
#define SSD2119_H_RAM_START_REG         0x45
#define SSD2119_H_RAM_END_REG           0x46
#define SSD2119_X_RAM_ADDR_REG          0x4E
#define SSD2119_Y_RAM_ADDR_REG          0x4F

#define ENTRY_MODE_DEFAULT              0x6830


/*************************** FMC Routines ************************************/
static void FMC_BANK1_MspInit(void)
{
  GPIO_InitTypeDef gpio;

  /* Enable FSMC clock */
  __HAL_RCC_FSMC_CLK_ENABLE();

  /* Enable GPIOs clock */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();

  /* Common GPIO configuration */
  gpio.Mode      = GPIO_MODE_AF_PP;
  gpio.Pull      = GPIO_PULLUP;
  gpio.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
  gpio.Alternate = GPIO_AF12_FSMC;

  /* GPIOD configuration */
  gpio.Pin       = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_4 | GPIO_PIN_5
                 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10
                 | GPIO_PIN_14 | GPIO_PIN_15;
  HAL_GPIO_Init( GPIOD, &gpio );

  /* GPIOE configuration */
  gpio.Pin       = GPIO_PIN_3 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9
                 | GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13
                 | GPIO_PIN_14 | GPIO_PIN_15;
  HAL_GPIO_Init( GPIOE, &gpio );
}


static void FMC_BANK1_Init(void)
{
  SRAM_HandleTypeDef hsram;
  FMC_NORSRAM_TimingTypeDef sram_timing_rd;
  FMC_NORSRAM_TimingTypeDef sram_timing_wr;

  /* configure IPs */
  hsram.Instance                       = FSMC_NORSRAM_DEVICE;
  hsram.Extended                       = FSMC_NORSRAM_EXTENDED_DEVICE;

  /* timing for READING */
  sram_timing_rd.AddressSetupTime      = 9;
  sram_timing_rd.AddressHoldTime       = 1;
  sram_timing_rd.DataSetupTime         = 36;
  sram_timing_rd.BusTurnAroundDuration = 1;
  sram_timing_rd.CLKDivision           = 2;
  sram_timing_rd.DataLatency           = 2;
  sram_timing_rd.AccessMode            = FSMC_ACCESS_MODE_A;

  /* timing for WRITTING */
  sram_timing_wr.AddressSetupTime      = 1;
  sram_timing_wr.AddressHoldTime       = 1;
  sram_timing_wr.DataSetupTime         = 7;
  sram_timing_wr.BusTurnAroundDuration = 0;
  sram_timing_wr.CLKDivision           = 2;
  sram_timing_wr.DataLatency           = 2;
  sram_timing_wr.AccessMode            = FSMC_ACCESS_MODE_A;

  hsram.Init.NSBank                    = FSMC_NORSRAM_BANK1;
  hsram.Init.DataAddressMux            = FSMC_DATA_ADDRESS_MUX_DISABLE;
  hsram.Init.MemoryType                = FSMC_MEMORY_TYPE_SRAM;
  hsram.Init.MemoryDataWidth           = FSMC_NORSRAM_MEM_BUS_WIDTH_16;
  hsram.Init.BurstAccessMode           = FSMC_BURST_ACCESS_MODE_DISABLE;
  hsram.Init.WaitSignalPolarity        = FSMC_WAIT_SIGNAL_POLARITY_LOW;
  hsram.Init.WrapMode                  = FSMC_WRAP_MODE_DISABLE;
  hsram.Init.WaitSignalActive          = FSMC_WAIT_TIMING_BEFORE_WS;
  hsram.Init.WriteOperation            = FSMC_WRITE_OPERATION_ENABLE;
  hsram.Init.WaitSignal                = FSMC_WAIT_SIGNAL_DISABLE;
  hsram.Init.ExtendedMode              = FSMC_EXTENDED_MODE_DISABLE;
  hsram.Init.AsynchronousWait          = FSMC_ASYNCHRONOUS_WAIT_DISABLE;
  hsram.Init.WriteBurst                = FSMC_WRITE_BURST_DISABLE;
  hsram.Init.PageSize                  = FSMC_PAGE_SIZE_NONE;
  hsram.Init.ContinuousClock           = FSMC_CONTINUOUS_CLOCK_SYNC_ONLY;

  /* initialize the SRAM controller */
  FMC_BANK1_MspInit();
  HAL_SRAM_Init( &hsram, &sram_timing_rd, &sram_timing_wr );
}


/* helper function to initialize reset and backlight pins of LCD and to perform
   proper reset of display */
static void SSD2119_ResetDisplay()
{
  GPIO_InitTypeDef gpio;

  /* enable clock for LCD reset pin */
  LCD_RESET_GPIO_CLK_ENABLE();

  /* configure GPIO for LCD reset pin */
  gpio.Pin   = LCD_RESET_PIN;
  gpio.Pull  = GPIO_NOPULL;
  gpio.Speed = GPIO_SPEED_FAST;
  gpio.Mode  = GPIO_MODE_OUTPUT_PP;
  HAL_GPIO_Init( LCD_RESET_GPIO_PORT, &gpio );

  /* apply hardware reset */
  HAL_GPIO_WritePin( LCD_RESET_GPIO_PORT, LCD_RESET_PIN, GPIO_PIN_RESET );
  HAL_Delay( 5 );   /* reset signal asserted during 5ms  */
  HAL_GPIO_WritePin( LCD_RESET_GPIO_PORT, LCD_RESET_PIN, GPIO_PIN_SET );
  HAL_Delay( 10 );  /* reset signal released during 10ms */
  HAL_GPIO_WritePin( LCD_RESET_GPIO_PORT, LCD_RESET_PIN, GPIO_PIN_RESET );
  HAL_Delay( 20 );  /* reset signal asserted during 20ms */
  HAL_GPIO_WritePin( LCD_RESET_GPIO_PORT, LCD_RESET_PIN, GPIO_PIN_SET );
  HAL_Delay( 10 );  /* reset signal released during 10ms */

  /* enable clock for LCD backlight control pin */
  LCD_BL_CTRL_GPIO_CLK_ENABLE();

  /* configure GPIO for LCD backlight control pin */
  gpio.Pin  = LCD_BL_CTRL_PIN;
  gpio.Mode = GPIO_MODE_OUTPUT_PP;
  HAL_GPIO_Init( LCD_BL_CTRL_GPIO_PORT, &gpio );

  /* switch backlight on */
  HAL_GPIO_WritePin( LCD_BL_CTRL_GPIO_PORT, LCD_BL_CTRL_PIN, GPIO_PIN_SET );
}


/* helper function to set a command register value */
static void SSD2119_WriteReg( uint8_t aReg, uint16_t aValue )
{
  *SSD2119_Cmnd = aReg;
  *SSD2119_Data = aValue;
}


/* helper function to read a data value */
/*
static uint16_t SSD2119_ReadData( void )
{
  return *SSD2119_Data;
}
*/


/*******************************************************************************
* FUNCTION:
*   SSD2119_Init
*
* DESCRIPTION:
*   The function initializes the FSMC hardware and all necessary GPIO in order
*   to reset and intialize the connected display hardware.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void SSD2119_Init( void )
{
  /* initialize FSMC hardware (16bit, 8080 interface) */
  FMC_BANK1_Init();

  /* perform reset of LCD */
  SSD2119_ResetDisplay();

  /* Enter sleep mode (if we are not already there).*/
  SSD2119_WriteReg( SSD2119_SLEEP_MODE_1_REG, 0x0001 );

  /* Set initial power parameters. */
  SSD2119_WriteReg( SSD2119_PWR_CTRL_5_REG, 0x00B2 );
  SSD2119_WriteReg( SSD2119_VCOM_OTP_1_REG, 0x0006 );

  /* Start the oscillator.*/
  SSD2119_WriteReg( SSD2119_OSC_START_REG, 0x0001 );

  /* Set pixel format and basic display orientation (scanning direction).*/
  SSD2119_WriteReg( SSD2119_OUTPUT_CTRL_REG, 0x30EF ); /* 0x72EF for rotation by 180 degrees */
  SSD2119_WriteReg( SSD2119_LCD_DRIVE_AC_CTRL_REG, 0x0600 );

  /* Exit sleep mode.*/
  SSD2119_WriteReg( SSD2119_SLEEP_MODE_1_REG, 0x0000 );
  HAL_Delay( 100 );

  /* Configure pixel color format and MCU interface parameters.*/
  SSD2119_WriteReg( SSD2119_ENTRY_MODE_REG, ENTRY_MODE_DEFAULT );

  /* Set analog parameters */
  SSD2119_WriteReg( SSD2119_SLEEP_MODE_2_REG, 0x0999 );
  SSD2119_WriteReg( SSD2119_ANALOG_SET_REG, 0x3800 );

  /* Enable the display */
  SSD2119_WriteReg( SSD2119_DISPLAY_CTRL_REG, 0x0033 );

  /* Set VCIX2 voltage to 6.1V.*/
  SSD2119_WriteReg( SSD2119_PWR_CTRL_2_REG, 0x0005 );

  /* Configure gamma correction.*/
  SSD2119_WriteReg( SSD2119_GAMMA_CTRL_1_REG, 0x0000 );
  SSD2119_WriteReg( SSD2119_GAMMA_CTRL_2_REG, 0x0303 );
  SSD2119_WriteReg( SSD2119_GAMMA_CTRL_3_REG, 0x0407 );
  SSD2119_WriteReg( SSD2119_GAMMA_CTRL_4_REG, 0x0301 );
  SSD2119_WriteReg( SSD2119_GAMMA_CTRL_5_REG, 0x0301 );
  SSD2119_WriteReg( SSD2119_GAMMA_CTRL_6_REG, 0x0403 );
  SSD2119_WriteReg( SSD2119_GAMMA_CTRL_7_REG, 0x0707 );
  SSD2119_WriteReg( SSD2119_GAMMA_CTRL_8_REG, 0x0400 );
  SSD2119_WriteReg( SSD2119_GAMMA_CTRL_9_REG, 0x0a00 );
  SSD2119_WriteReg( SSD2119_GAMMA_CTRL_10_REG, 0x1000 );

  /* Configure Vlcd63 and VCOMl */
  SSD2119_WriteReg( SSD2119_PWR_CTRL_3_REG, 0x000A );
  SSD2119_WriteReg( SSD2119_PWR_CTRL_4_REG, 0x2E00 );
  HAL_Delay( 100 );

  /* Set the display size and ensure that the GRAM window is set to allow
     access to the full display buffer.*/
  SSD2119_WriteReg( SSD2119_V_RAM_POS_REG, (DISPLAY_PIXEL_HEIGHT - 1) << 8 );
  SSD2119_WriteReg( SSD2119_H_RAM_START_REG, 0x0000 );
  SSD2119_WriteReg( SSD2119_H_RAM_END_REG, DISPLAY_PIXEL_WIDTH - 1 );

  SSD2119_WriteReg( SSD2119_X_RAM_ADDR_REG, 0x00 );
  SSD2119_WriteReg( SSD2119_Y_RAM_ADDR_REG, 0x00 );
}


/*******************************************************************************
* FUNCTION:
*   SSD2119_ReadID
*
* DESCRIPTION:
*   The function assumes a connected and intialized SSD2119 display and tries
*   to read its ID.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   If successful, the function returns the ID of the display - 0 otherwise.
*
*******************************************************************************/
uint16_t SSD2119_ReadID(void)
{
  return SSD2119_ID;
}


/*******************************************************************************
* FUNCTION:
*   SSD2119_SetDataPosition
*
* DESCRIPTION:
*   The function sets the destination position within the framebuffer of the
*   display according the given x/y position.
*
* ARGUMENTS:
*   aX       - Horizontal position for next write access.
*   aY       - Vertical position for next write access.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void SSD2119_SetDataPosition( uint16_t aX, uint16_t aY )
{
  /* set the GRAM window to entire display size */
  SSD2119_WriteReg( SSD2119_V_RAM_POS_REG, ( DISPLAY_PIXEL_HEIGHT - 1 ) << 8 );
  SSD2119_WriteReg( SSD2119_H_RAM_START_REG, 0x0000 );
  SSD2119_WriteReg( SSD2119_H_RAM_END_REG, DISPLAY_PIXEL_WIDTH - 1 );

  SSD2119_WriteReg( SSD2119_X_RAM_ADDR_REG, aX );
  SSD2119_WriteReg( SSD2119_Y_RAM_ADDR_REG, aY );

  /* set command to make subsequent data transfers */
  *SSD2119_Cmnd = SSD2119_RAM_DATA_REG;
}


/*******************************************************************************
* FUNCTION:
*   SSD2119_SetDataWindow
*
* DESCRIPTION:
*   The function sets the destination position and size within the framebuffer
*   of the display according the given rectangle.
*
* ARGUMENTS:
*   aX       - Horizontal position for next write access.
*   aY       - Vertical position for next write access.
*   aW       - Width of the data window in pixel.
*   aH       - Height of the data window in pixel.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void SSD2119_SetDataWindow( uint16_t aX, uint16_t aY, uint16_t aW, uint16_t aH )
{
  int xEnd = aX + aW - 1;
  int yEnd = aY + aH - 1;

  if ( xEnd >= DISPLAY_PIXEL_WIDTH )
    xEnd = DISPLAY_PIXEL_WIDTH - 1;
  if ( yEnd >= DISPLAY_PIXEL_HEIGHT )
    yEnd = DISPLAY_PIXEL_HEIGHT - 1;

  SSD2119_WriteReg( SSD2119_V_RAM_POS_REG, (( yEnd & 0xFF ) << 8) | ( aY & 0xFF ));
  SSD2119_WriteReg( SSD2119_H_RAM_START_REG, aX );
  SSD2119_WriteReg( SSD2119_H_RAM_END_REG, xEnd );

  SSD2119_WriteReg( SSD2119_X_RAM_ADDR_REG, aX );
  SSD2119_WriteReg( SSD2119_Y_RAM_ADDR_REG, aY );

  /* set command to make subsequent data transfers */
  *SSD2119_Cmnd = SSD2119_RAM_DATA_REG;
}


/*******************************************************************************
* FUNCTION:
*   SSD2119_WriteData
*
* DESCRIPTION:
*   Write a single data word to the SSD2119 display.
*
* ARGUMENTS:
*   aData    - 16 bit value to be sent to the SSD2119 display.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void SSD2119_WriteData( uint16_t aData )
{
  *SSD2119_Data = aData;
}


/*******************************************************************************
* FUNCTION:
*   SSD2119_WriteMultipleData
*
* DESCRIPTION:
*   Write a sequence of data words to the SSD2119 display.
*
* ARGUMENTS:
*   aData    - pointer to 16 bit values to be sent to the SSD2119 display.
*   aSize    - Number of data values to be sent.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void SSD2119_WriteMultipleData( uint16_t* aData, uint32_t aSize )
{
  while ( aSize-- )
    *SSD2119_Data = *aData++;
}


/* msy */

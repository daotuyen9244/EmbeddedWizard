/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is delivered "as is" and shows the usage of other software
* components. It is provided as an example software which is intended to be
* modified and extended according to particular requirements.
*
* TARA Systems hereby disclaims all warranties and conditions with regard to the
* software, including all implied warranties and conditions of merchantability
* and non-infringement of any third party IPR or other rights which may result
* from the use or the inability to use the software.
*
********************************************************************************
*
* DESCRIPTION:
*   This file contains the necessary initialization of the SSD1963 display
*   controller and the necessary function to update a rectangular area of the
*   screen from an Embedded Wizard UI application.
*   The data transfer is done by using the hardware FSMC controller via the
*   16bit 8080 interface. The color format of the display is RGB565.
*
*   This driver assumes the following layout of the interface:
*   Data lines D0...D15 (FSMC):
*     D0   - PD14
*     D1   - PD15
*     D2   - PD0
*     D3   - PD1
*     D4   - PE7
*     D5   - PE8
*     D6   - PE9
*     D7   - PE10
*     D8   - PE11
*     D9   - PE12
*     D10  - PE13
*     D11  - PE14
*     D12  - PE15
*     D13  - PD8
*     D14  - PD9
*     D15  - PD10
*   Control lines (FSCM):
*     /CS  - PD7   (FSMC_NE1) => chip select, low active
*     /RD  - PD4   (FSMC_NOE) => read access, low active
*     /WR  - PD5   (FSMC_NWE) => write access, low active
*     DC   - PE3   (A19)      => register select (data/command)
*   Additional control lines:
*     /RST - PD3              => reset of LCD module, low active
*
*   This module is just a template - adapt pin configuration and timing (!)
*   according your hardware layout and hardware constraints.
*   Adjust device parameters, initialization and gamma correction values
*   according your display and your needs.
*   This driver was tested on a HY35A display module (3,5" TFT 320x240).
*
*******************************************************************************/

#include "stm32f4xx_hal.h"

#include "ssd1963_16bit_fsmc.h"

/* LCD reset pin */
#define LCD_RESET_PIN                   GPIO_PIN_3
#define LCD_RESET_GPIO_PORT             GPIOD
#define LCD_RESET_GPIO_CLK_ENABLE()     __HAL_RCC_GPIOD_CLK_ENABLE()
#define LCD_RESET_GPIO_CLK_DISABLE()    __HAL_RCC_GPIOD_CLK_DISABLE()

/* backlight control pin */
//#define LCD_BL_CTRL_PIN                 GPIO_PIN_13
//#define LCD_BL_CTRL_GPIO_PORT           GPIOD
//#define LCD_BL_CTRL_GPIO_CLK_ENABLE()   __HAL_RCC_GPIOD_CLK_ENABLE()
//#define LCD_BL_CTRL_GPIO_CLK_DISABLE()  __HAL_RCC_GPIOD_CLK_DISABLE()

/* FSMC addresses for command and data port of SSD1963 */
#define SSD1963_Cmnd (__IO uint16_t*)((uint32_t)0x60000000)
#define SSD1963_Data (__IO uint16_t*)((uint32_t)0x60100000)

/* display specific settings */
#define DISPLAY_PIXEL_WIDTH             ((uint16_t)320)
#define DISPLAY_PIXEL_HEIGHT            ((uint16_t)240)

/* horizontal LCD timings (from glass datasheet) */
#define DISPLAY_HORI_PULSE_WIDTH		    20
#define DISPLAY_HORI_BACK_PORCH			    51
#define DISPLAY_HORI_FRONT_PORCH		    20

/* vertical LCD timings (from glass datasheet) */
#define DISPLAY_VERT_PULSE_WIDTH		    2
#define DISPLAY_VERT_BACK_PORCH			    12
#define DISPLAY_VERT_FRONT_PORCH		    4

/* SSD1963 commands (from SSD1963 datasheet) */
#define SSD1963_NOP                     0x00
#define SSD1963_SOFT_RESET              0x01
#define SSD1963_GET_POWER_MODE          0x0A
#define SSD1963_GET_ADDRESS_MODE        0x0B
#define SSD1963_GET_PIXEL_FORMAT        0x0C
#define SSD1963_GET_DISPLAY_MODE        0x0D
#define SSD1963_GET_SIGNAL_MODE         0x0E
#define SSD1963_ENTER_SLEEP_MODE        0x10
#define SSD1963_EXIT_SLEEP_MODE         0x11
#define SSD1963_ENTER_PARTIAL_MODE      0x12
#define SSD1963_ENTER_NORMAL_MODE       0x13
#define SSD1963_EXIT_INVERT_MODE        0x20
#define SSD1963_ENTER_INVERT_MODE       0x21
#define SSD1963_SET_GAMMA_CURVE         0x26
#define SSD1963_SET_DISPLAY_OFF         0x28
#define SSD1963_SET_DISPLAY_ON          0x29
#define SSD1963_SET_COLUMN_ADDRESS      0x2A
#define SSD1963_SET_PAGE_ADDRESS        0x2B
#define SSD1963_WRITE_MEMORY_START      0x2C
#define SSD1963_READ_MEMORY_START       0x2E
#define SSD1963_SET_PARTIAL_AREA        0x30
#define SSD1963_SET_SCROLL_AREA         0x33
#define SSD1963_SET_TEAR_OFF            0x34
#define SSD1963_SET_TEAR_ON             0x35
#define SSD1963_SET_ADDRESS_MODE        0x36
#define SSD1963_SET_SCROLL_START        0x37
#define SSD1963_EXIT_IDLE_MODE          0x38
#define SSD1963_ENTER_IDLE_MODE         0x39
#define SSD1963_SET_PIXEL_FORMAT        0x3A
#define SSD1963_WRITE_MEMORY_CONTINUE   0x3C
#define SSD1963_READ_MEMORY_CONTINUE    0x3E
#define SSD1963_SET_TEAR_SCANLINE       0x44
#define SSD1963_GET_SCANLINE            0x45
#define SSD1963_READ_DDB                0xA1
#define SSD1963_MSY                     0xA8
#define SSD1963_SET_LCD_MODE            0xB0
#define SSD1963_GET_LCD_MODE            0xB1
#define SSD1963_SET_HORI_PERIOD         0xB4
#define SSD1963_GET_HORI_PERIOD         0xB5
#define SSD1963_SET_VERT_PERIOD         0xB6
#define SSD1963_GET_VERT_PERIOD         0xB7
#define SSD1963_SET_GPIO_CONF           0xB8
#define SSD1963_GET_GPIO_CONF           0xB9
#define SSD1963_SET_GPIO_VALUE          0xBA
#define SSD1963_GET_GPIO_STATUS         0xBB
#define SSD1963_SET_POST_PROC           0xBC
#define SSD1963_GET_POST_PROC           0xBD
#define SSD1963_SET_PWM_CONF            0xBE
#define SSD1963_GET_PWM_CONF            0xBF
#define SSD1963_SET_LCD_GEN0            0xC0
#define SSD1963_GET_LCD_GEN0            0xC1
#define SSD1963_SET_LCD_GEN1            0xC2
#define SSD1963_GET_LCD_GEN1            0xC3
#define SSD1963_SET_LCD_GEN2            0xC4
#define SSD1963_GET_LCD_GEN2            0xC5
#define SSD1963_SET_LCD_GEN3            0xC6
#define SSD1963_GET_LCD_GEN3            0xC7
#define SSD1963_SET_GPIO0_ROP           0xC8
#define SSD1963_GET_GPIO0_ROP           0xC9
#define SSD1963_SET_GPIO1_ROP           0xCA
#define SSD1963_GET_GPIO1_ROP           0xCB
#define SSD1963_SET_GPIO2_ROP           0xCC
#define SSD1963_GET_GPIO2_ROP           0xCD
#define SSD1963_SET_GPIO3_ROP           0xCE
#define SSD1963_GET_GPIO3_ROP           0xCF
#define SSD1963_SET_DBC_CONF            0xD0
#define SSD1963_GET_DBC_CONF            0xD1
#define SSD1963_SET_DBC_TH              0xD4
#define SSD1963_GET_DBC_TH              0xD5
#define SSD1963_SET_PLL                 0xE0
#define SSD1963_SET_PLL_MN              0xE2
#define SSD1963_GET_PLL_MN              0xE3
#define SSD1963_GET_PLL_STATUS          0xE4
#define SSD1963_SET_DEEP_SLEEP          0xE5
#define SSD1963_SET_LSHIFT_FREQ         0xE6
#define SSD1963_GET_LSHIFT_FREQ         0xE7
#define SSD1963_SET_PIXEL_DATA_IFC      0xF0
#define SSD1963_GET_PIXEL_DATA_IFC      0xF1


/*************************** FMC Routines ************************************/
static void FMC_BANK1_MspInit(void)
{
  GPIO_InitTypeDef gpio;

  /* Enable FSMC clock */
  __HAL_RCC_FSMC_CLK_ENABLE();

  /* Enable GPIOs clock */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();

  /* Common GPIO configuration */
  gpio.Mode      = GPIO_MODE_AF_PP;
  gpio.Pull      = GPIO_PULLUP;
  gpio.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
  gpio.Alternate = GPIO_AF12_FSMC;

  /* GPIOD configuration */
  gpio.Pin       = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_4 | GPIO_PIN_5
                 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10
                 | GPIO_PIN_14 | GPIO_PIN_15;
  HAL_GPIO_Init( GPIOD, &gpio );

  /* GPIOE configuration */
  gpio.Pin       = GPIO_PIN_3 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9
                 | GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13
                 | GPIO_PIN_14 | GPIO_PIN_15;
  HAL_GPIO_Init( GPIOE, &gpio );
}


static void FMC_BANK1_Init(void)
{
  SRAM_HandleTypeDef hsram;
  FMC_NORSRAM_TimingTypeDef sram_timing_rd;
  FMC_NORSRAM_TimingTypeDef sram_timing_wr;

  /* configure IPs */
  hsram.Instance                       = FSMC_NORSRAM_DEVICE;
  hsram.Extended                       = FSMC_NORSRAM_EXTENDED_DEVICE;

  /* timing for READING */
  sram_timing_rd.AddressSetupTime      = 9;
  sram_timing_rd.AddressHoldTime       = 1;
  sram_timing_rd.DataSetupTime         = 36;
  sram_timing_rd.BusTurnAroundDuration = 1;
  sram_timing_rd.CLKDivision           = 2;
  sram_timing_rd.DataLatency           = 2;
  sram_timing_rd.AccessMode            = FSMC_ACCESS_MODE_A;

  /* timing for WRITTING */
  sram_timing_wr.AddressSetupTime      = 1;
  sram_timing_wr.AddressHoldTime       = 1;
  sram_timing_wr.DataSetupTime         = 7;
  sram_timing_wr.BusTurnAroundDuration = 0;
  sram_timing_wr.CLKDivision           = 2;
  sram_timing_wr.DataLatency           = 2;
  sram_timing_wr.AccessMode            = FSMC_ACCESS_MODE_A;

  hsram.Init.NSBank                    = FSMC_NORSRAM_BANK1;
  hsram.Init.DataAddressMux            = FSMC_DATA_ADDRESS_MUX_DISABLE;
  hsram.Init.MemoryType                = FSMC_MEMORY_TYPE_SRAM;
  hsram.Init.MemoryDataWidth           = FSMC_NORSRAM_MEM_BUS_WIDTH_16;
  hsram.Init.BurstAccessMode           = FSMC_BURST_ACCESS_MODE_DISABLE;
  hsram.Init.WaitSignalPolarity        = FSMC_WAIT_SIGNAL_POLARITY_LOW;
  hsram.Init.WrapMode                  = FSMC_WRAP_MODE_DISABLE;
  hsram.Init.WaitSignalActive          = FSMC_WAIT_TIMING_BEFORE_WS;
  hsram.Init.WriteOperation            = FSMC_WRITE_OPERATION_ENABLE;
  hsram.Init.WaitSignal                = FSMC_WAIT_SIGNAL_DISABLE;
  hsram.Init.ExtendedMode              = FSMC_EXTENDED_MODE_DISABLE;
  hsram.Init.AsynchronousWait          = FSMC_ASYNCHRONOUS_WAIT_DISABLE;
  hsram.Init.WriteBurst                = FSMC_WRITE_BURST_DISABLE;
  hsram.Init.PageSize                  = FSMC_PAGE_SIZE_NONE;
  hsram.Init.ContinuousClock           = FSMC_CONTINUOUS_CLOCK_SYNC_ONLY;

  /* initialize the SRAM controller */
  FMC_BANK1_MspInit();
  HAL_SRAM_Init( &hsram, &sram_timing_rd, &sram_timing_wr );
}


/* helper function to initialize reset and backlight pins of LCD and to perform
   proper reset of display */
static void SSD1963_ResetDisplay()
{
  GPIO_InitTypeDef gpio;

  /* enable clock for LCD reset pin */
  LCD_RESET_GPIO_CLK_ENABLE();

  /* configure GPIO for LCD reset pin */
  gpio.Pin   = LCD_RESET_PIN;
  gpio.Pull  = GPIO_NOPULL;
  gpio.Speed = GPIO_SPEED_FAST;
  gpio.Mode  = GPIO_MODE_OUTPUT_PP;
  HAL_GPIO_Init( LCD_RESET_GPIO_PORT, &gpio );

  /* apply hardware reset */
  HAL_GPIO_WritePin( LCD_RESET_GPIO_PORT, LCD_RESET_PIN, GPIO_PIN_RESET );
  HAL_Delay( 100 );  /* reset signal asserted during 100ms */
  HAL_GPIO_WritePin( LCD_RESET_GPIO_PORT, LCD_RESET_PIN, GPIO_PIN_SET );
  HAL_Delay( 10 );  /* reset signal released during 10ms */

  /* enable clock for LCD backlight control pin */
  // LCD_BL_CTRL_GPIO_CLK_ENABLE();

  /* configure GPIO for LCD backlight control pin */
  // gpio.Pin  = LCD_BL_CTRL_PIN;
  // gpio.Mode = GPIO_MODE_OUTPUT_PP;
  // HAL_GPIO_Init( LCD_BL_CTRL_GPIO_PORT, &gpio );

  /* switch backlight on */
  // HAL_GPIO_WritePin( LCD_BL_CTRL_GPIO_PORT, LCD_BL_CTRL_PIN, GPIO_PIN_SET );
}


/* helper function to set a command register value */
static void SSD1963_WriteReg( uint8_t aReg )
{
  *SSD1963_Cmnd = aReg;
}


/* helper function to read a data value */
static uint16_t SSD1963_ReadData( void )
{
  return *SSD1963_Data;
}


/*******************************************************************************
* FUNCTION:
*   SSD1963_Init
*
* DESCRIPTION:
*   The function initializes the FSMC hardware and all necessary GPIO in order
*   to reset and intialize the connected display hardware.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void SSD1963_Init( void )
{
  /* initialize FSMC hardware (16bit, 8080 interface) */
  FMC_BANK1_Init();

  /* perform reset of LCD */
  SSD1963_ResetDisplay();

  /* calculate 120MHz PLL frequency based on 10MHz crystal */
  SSD1963_WriteReg( SSD1963_SET_PLL_MN );
  SSD1963_WriteData( 0x23 ); /* mult: 10MHz * 36 = 360MHz VCO freq (-1) => 35 */
  SSD1963_WriteData( 0x02 ); /* div: 360MHz / 3 = 120 MHz PLL freq (-1) => 2*/
  SSD1963_WriteData( 0x54 ); /* effectuate values */

  /* start PLL and wait for synchronizing */
  SSD1963_WriteReg( SSD1963_SET_PLL );
  SSD1963_WriteData( 0x01 );
  HAL_Delay( 10 );

  /* use PLL as clock source */
  SSD1963_WriteReg( SSD1963_SET_PLL );
  SSD1963_WriteData( 0x03 );
  HAL_Delay( 10 );

  /* make a software reset */
  SSD1963_WriteReg( SSD1963_SOFT_RESET );
  HAL_Delay( 10 );

  /* set mode and size of display */
  SSD1963_WriteReg( SSD1963_SET_LCD_MODE );
  SSD1963_WriteData( 0x20 );
  SSD1963_WriteData( 0x00 );
  SSD1963_WriteData(( DISPLAY_PIXEL_WIDTH - 1 ) >> 8 );
  SSD1963_WriteData(( DISPLAY_PIXEL_WIDTH - 1) & 0xFF );
  SSD1963_WriteData(( DISPLAY_PIXEL_HEIGHT - 1 ) >> 8 );
  SSD1963_WriteData(( DISPLAY_PIXEL_HEIGHT - 1 ) & 0xFF );
  SSD1963_WriteData( 0x00 );

  /* set pixel clock frequency */
  /* display requires 6.5 MHz pixel clock */
  /* LCDC_FPR = 2^20 * pixel clock / PLL freq */
  /* 2^20 * 6.5 / 120 = 56797 (-1) => 0xDDDC */
  SSD1963_WriteReg( SSD1963_SET_LSHIFT_FREQ );
  SSD1963_WriteData( 0x00 );
  SSD1963_WriteData( 0xDD );
  SSD1963_WriteData( 0xDC );

  /* set horizontal display timing */
	#define HT ( DISPLAY_PIXEL_WIDTH + DISPLAY_HORI_PULSE_WIDTH + DISPLAY_HORI_BACK_PORCH + DISPLAY_HORI_FRONT_PORCH - 1 )
	#define HPS ( DISPLAY_HORI_PULSE_WIDTH + DISPLAY_HORI_BACK_PORCH - 1 )
	#define HPW ( DISPLAY_HORI_PULSE_WIDTH - 1 )
  SSD1963_WriteReg( SSD1963_SET_HORI_PERIOD );
	SSD1963_WriteData( HT >> 8 );
	SSD1963_WriteData( HT & 0xFF );
	SSD1963_WriteData( HPS >> 8 );
	SSD1963_WriteData( HPS & 0xFF );
	SSD1963_WriteData( HPW );
	SSD1963_WriteData( 0x00 );
	SSD1963_WriteData( 0x00 );
	SSD1963_WriteData( 0x00 );

  /* set vertical display timing */
  SSD1963_WriteReg( SSD1963_SET_VERT_PERIOD );
	#define VT ( DISPLAY_VERT_PULSE_WIDTH + DISPLAY_VERT_BACK_PORCH + DISPLAY_VERT_FRONT_PORCH + DISPLAY_PIXEL_HEIGHT - 1 )
	#define VSP ( DISPLAY_VERT_PULSE_WIDTH + DISPLAY_VERT_BACK_PORCH - 1 )
	#define VPW ( DISPLAY_VERT_PULSE_WIDTH - 1 )
	SSD1963_WriteData( VT >> 8 );
	SSD1963_WriteData( VT & 0xFF );
	SSD1963_WriteData( VSP >> 8 );
	SSD1963_WriteData( VSP & 0xFF );
	SSD1963_WriteData( VPW );
	SSD1963_WriteData( 0x00 );
	SSD1963_WriteData( 0x00 );

  SSD1963_WriteReg( SSD1963_SET_PIXEL_FORMAT );
  SSD1963_WriteData( 0x50 );

  SSD1963_WriteReg( SSD1963_SET_PIXEL_DATA_IFC );
  SSD1963_WriteData( 0x03 );

  /* switch display on */
  SSD1963_WriteReg( SSD1963_SET_DISPLAY_ON );

  /* configure PWM for LCD backight */
	SSD1963_WriteReg( SSD1963_SET_PWM_CONF );
	SSD1963_WriteData( 0x0E ); /* 122Hz @PLL freq 120MHz */
	SSD1963_WriteData( 0xFF ); /* full intensity (255/256) */
	SSD1963_WriteData( 0x01 ); /* PWM enabled */
	SSD1963_WriteData( 0x00 );
	SSD1963_WriteData( 0x00 );
	SSD1963_WriteData( 0x00 );
}


/*******************************************************************************
* FUNCTION:
*   SSD1963_ReadID
*
* DESCRIPTION:
*   The function assumes a connected and intialized SSD1963 display and tries
*   to read its ID.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   If successful, the function returns the ID of the display - 0 otherwise.
*
*******************************************************************************/
uint16_t SSD1963_ReadID(void)
{
  uint16_t data[ 5 ];

  /* read the device descriptor block */
  SSD1963_WriteReg( SSD1963_READ_DDB );
  data[ 0 ] = SSD1963_ReadData();
  data[ 1 ] = SSD1963_ReadData();
  data[ 2 ] = SSD1963_ReadData();
  data[ 3 ] = SSD1963_ReadData();
  data[ 4 ] = SSD1963_ReadData();

  /* check for valid data */
  if (( data [ 0 ] != 0x01 ) || ( data [ 1 ] != 0x57 ) || ( data [ 2 ] != 0x61 )
    || ( data [ 3 ] != 0x01 ) || ( data [ 4 ] != 0xFF ))
    return 0;

  return SSD1963_ID;
}


/*******************************************************************************
* FUNCTION:
*   SSD1963_SetDataPosition
*
* DESCRIPTION:
*   The function sets the destination position within the framebuffer of the
*   display according the given x/y position.
*
* ARGUMENTS:
*   aX       - Horizontal position for next write access.
*   aY       - Vertical position for next write access.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void SSD1963_SetDataPosition( uint16_t aX, uint16_t aY )
{
  SSD1963_WriteReg( SSD1963_SET_COLUMN_ADDRESS );
  SSD1963_WriteData(( aX >> 8 ) & 0xFF );
  SSD1963_WriteData(( aX >> 0 ) & 0xFF );
  SSD1963_WriteData((( DISPLAY_PIXEL_WIDTH - 1 ) >> 8 ) & 0xFF );
  SSD1963_WriteData((( DISPLAY_PIXEL_WIDTH - 1 ) >> 0 ) & 0xFF );

  SSD1963_WriteReg( SSD1963_SET_PAGE_ADDRESS );
  SSD1963_WriteData(( aY >> 8 ) & 0xFF );
  SSD1963_WriteData(( aY >> 0 ) & 0xFF );
  SSD1963_WriteData((( DISPLAY_PIXEL_HEIGHT - 1 ) >> 8 ) & 0xFF );
  SSD1963_WriteData((( DISPLAY_PIXEL_HEIGHT - 1 ) >> 0 ) & 0xFF );

  SSD1963_WriteReg( SSD1963_ENTER_PARTIAL_MODE );

  /* set command to make subsequent data transfers */
  SSD1963_WriteReg( SSD1963_WRITE_MEMORY_START );
}


/*******************************************************************************
* FUNCTION:
*   SSD1963_SetDataWindow
*
* DESCRIPTION:
*   The function sets the destination position and size within the framebuffer
*   of the display according the given rectangle.
*
* ARGUMENTS:
*   aX       - Horizontal position for next write access.
*   aY       - Vertical position for next write access.
*   aW       - Width of the data window in pixel.
*   aH       - Height of the data window in pixel.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void SSD1963_SetDataWindow( uint16_t aX, uint16_t aY, uint16_t aW, uint16_t aH )
{
  int xEnd = aX + aW - 1;
  int yEnd = aY + aH - 1;

  if ( xEnd >= DISPLAY_PIXEL_WIDTH )
    xEnd = DISPLAY_PIXEL_WIDTH - 1;
  if ( yEnd >= DISPLAY_PIXEL_HEIGHT )
    yEnd = DISPLAY_PIXEL_HEIGHT - 1;

  SSD1963_WriteReg( SSD1963_SET_COLUMN_ADDRESS );
  SSD1963_WriteData(( aX >> 8 ) & 0xFF );
  SSD1963_WriteData(( aX >> 0 ) & 0xFF );
  SSD1963_WriteData(( xEnd >> 8 ) & 0xFF );
  SSD1963_WriteData(( xEnd >> 0 ) & 0xFF );

  SSD1963_WriteReg( SSD1963_SET_PAGE_ADDRESS );
  SSD1963_WriteData(( aY >> 8 ) & 0xFF );
  SSD1963_WriteData(( aY >> 0 ) & 0xFF );
  SSD1963_WriteData(( yEnd >> 8 ) & 0xFF );
  SSD1963_WriteData(( yEnd >> 0 ) & 0xFF );

  SSD1963_WriteReg( SSD1963_ENTER_PARTIAL_MODE );

  /* set command to make subsequent data transfers */
  SSD1963_WriteReg( SSD1963_WRITE_MEMORY_START );
}


/*******************************************************************************
* FUNCTION:
*   SSD1963_WriteData
*
* DESCRIPTION:
*   Write a single data word to the SSD1963 display.
*
* ARGUMENTS:
*   aData    - 16 bit value to be sent to the SSD1963 display.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void SSD1963_WriteData( uint16_t aData )
{
  *SSD1963_Data = aData;
}


/*******************************************************************************
* FUNCTION:
*   SSD1963_WriteMultipleData
*
* DESCRIPTION:
*   Write a sequence of data words to the SSD1963 display.
*
* ARGUMENTS:
*   aData    - pointer to 16 bit values to be sent to the SSD1963 display.
*   aSize    - Number of data values to be sent.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void SSD1963_WriteMultipleData( uint16_t* aData, uint32_t aSize )
{
  while ( aSize-- )
    *SSD1963_Data = *aData++;
}


/* msy */

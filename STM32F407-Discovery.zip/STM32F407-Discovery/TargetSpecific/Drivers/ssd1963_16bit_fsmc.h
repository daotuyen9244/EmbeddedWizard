/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is delivered "as is" and shows the usage of other software
* components. It is provided as an example software which is intended to be
* modified and extended according to particular requirements.
*
* TARA Systems hereby disclaims all warranties and conditions with regard to the
* software, including all implied warranties and conditions of merchantability
* and non-infringement of any third party IPR or other rights which may result
* from the use or the inability to use the software.
*
********************************************************************************
*
* DESCRIPTION:
*   This file contains the necessary initialization of the SSD1963 display
*   controller and the necessary function to update a rectangular area of the
*   screen from an Embedded Wizard UI application.
*   The data transfer is done by using the hardware FSMC controller via the
*   16bit 8080 interface. The color format of the display is RGB565.
*
*   This driver assumes the following layout of the interface:
*   Data lines D0...D15 (FSMC):
*     D0   - PD14
*     D1   - PD15
*     D2   - PD0
*     D3   - PD1
*     D4   - PE7
*     D5   - PE8
*     D6   - PE9
*     D7   - PE10
*     D8   - PE11
*     D9   - PE12
*     D10  - PE13
*     D11  - PE14
*     D12  - PE15
*     D13  - PD8
*     D14  - PD9
*     D15  - PD10
*   Control lines (FSCM):
*     /CS  - PD7   (FSMC_NE1) => chip select, low active
*     /RD  - PD4   (FSMC_NOE) => read access, low active
*     /WR  - PD5   (FSMC_NWE) => write access, low active
*     DC   - PE3   (A19)      => register select (data/command)
*   Additional control lines:
*     /RST - PD3              => reset of LCD module, low active
*
*   This module is just a template - adapt pin configuration and timing (!)
*   according your hardware layout and hardware constraints.
*   Adjust device parameters, initialization and gamma correction values
*   according your display and your needs.
*   This driver was tested on a HY35A display module (3,5" TFT 320x240).
*
*******************************************************************************/

#ifndef SSD1963_16BIT_FSMC_H
#define SSD1963_16BIT_FSMC_H


#ifdef __cplusplus
  extern "C"
  {
#endif


#define SSD1963_ID                      0x1963

/*******************************************************************************
* FUNCTION:
*   SSD1963_Init
*
* DESCRIPTION:
*   The function initializes the FSMC hardware and all necessary GPIO in order
*   to reset and intialize the connected display hardware.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void SSD1963_Init
(
  void
);


/*******************************************************************************
* FUNCTION:
*   SSD1963_ReadID
*
* DESCRIPTION:
*   The function assumes a connected and intialized SSD1963 display and tries
*   to read its ID.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   If successful, the function returns the ID of the display - 0 otherwise.
*
*******************************************************************************/
uint16_t SSD1963_ReadID
(
  void
);


/*******************************************************************************
* FUNCTION:
*   SSD1963_SetDataPosition
*
* DESCRIPTION:
*   The function sets the destination position within the framebuffer of the
*   display according the given x/y position.
*
* ARGUMENTS:
*   aX       - Horizontal position for next write access.
*   aY       - Vertical position for next write access.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void SSD1963_SetDataPosition
(
  uint16_t                    aX,
  uint16_t                    aY
);


/*******************************************************************************
* FUNCTION:
*   SSD1963_SetDataWindow
*
* DESCRIPTION:
*   The function sets the destination position and size within the framebuffer
*   of the display according the given rectangle.
*
* ARGUMENTS:
*   aX       - Horizontal position for next write access.
*   aY       - Vertical position for next write access.
*   aW       - Width of the data window in pixel.
*   aH       - Height of the data window in pixel.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void SSD1963_SetDataWindow
(
  uint16_t                    aX,
  uint16_t                    aY,
  uint16_t                    aW,
  uint16_t                    aH
);


/*******************************************************************************
* FUNCTION:
*   SSD1963_WriteData
*
* DESCRIPTION:
*   Write a single data word to the SSD1963 display.
*
* ARGUMENTS:
*   aData    - 16 bit value to be sent to the SSD1963 display.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void SSD1963_WriteData
(
  uint16_t                    aData
);


/*******************************************************************************
* FUNCTION:
*   SSD1963_WriteMultipleData
*
* DESCRIPTION:
*   Write a sequence of data words to the SSD1963 display.
*
* ARGUMENTS:
*   aData    - pointer to 16 bit values to be sent to the SSD1963 display.
*   aSize    - Number of data values to be sent.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void SSD1963_WriteMultipleData
(
  uint16_t*                   aData,
  uint32_t                    aSize
);


#ifdef __cplusplus
  }
#endif

#endif /* SSD1963_16BIT_FSMC_H */


/* msy */
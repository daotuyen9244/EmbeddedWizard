/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is delivered "as is" and shows the usage of other software
* components. It is provided as an example software which is intended to be
* modified and extended according to particular requirements.
*
* TARA Systems hereby disclaims all warranties and conditions with regard to the
* software, including all implied warranties and conditions of merchantability
* and non-infringement of any third party IPR or other rights which may result
* from the use or the inability to use the software.
*
********************************************************************************
*
* DESCRIPTION:
*   This file contains the necessary initialization of the XPT2046 (or ADS7843)
*   touch controller and the necessary function to read the current touch
*   position.
*   The data transfer is done by using the hardware SPI controller.
*
*   This driver assumes the following layout of the interface:
*   SPI2:
*     MISO - PC2
*     MOSI - PC3
*     SCK  - PB10
*   Control lines:
*     /CS  - PB14 (NSS) => chip select, low active
*     INT  - PC13       => (PENIRQ) touch detected, low active
*
*   This module is just a template - adapt pin configuration and timing (!)
*   according your hardware layout and hardware constraints.
*   Adjust device parameters, initialization and filtering of the touch
*   coordinates according your touch screen and your needs.
*
*******************************************************************************/

#include "stm32f4xx_hal.h"
#include "xpt2046_spi.h"

/* simple calibration and filtering data */
#define X_MIN                           100
#define X_MAX                           1900
#define Y_MIN                           1900
#define Y_MAX                           180
#define CHANGE_XY                       1
#define NO_OF_SAMPLES                   4

/* touch INT pin */
#define TOUCH_INT_PIN                   GPIO_PIN_13
#define TOUCH_INT_GPIO_PORT             GPIOC
#define TOUCH_INT_GPIO_CLK_ENABLE()     __HAL_RCC_GPIOC_CLK_ENABLE()
#define TOUCH_INT_GPIO_CLK_DISABLE()    __HAL_RCC_GPIOC_CLK_DISABLE()

/* touch CS pin */
#define TOUCH_CS_PIN                    GPIO_PIN_14
#define TOUCH_CS_GPIO_PORT              GPIOB
#define TOUCH_CS_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOB_CLK_ENABLE()
#define TOUCH_CS_GPIO_CLK_DISABLE()     __HAL_RCC_GPIOB_CLK_DISABLE()


SPI_HandleTypeDef                       hspi2;
static uint16_t                         TsXBoundary, TsYBoundary;


/*############################### SPIx #######################################*/

void HAL_SPI_MspInit( SPI_HandleTypeDef* hspi )
{
  GPIO_InitTypeDef GPIO_InitStruct;

  if ( hspi->Instance == SPI2 )
  {
    /* Peripheral clock enable */
    __HAL_RCC_SPI2_CLK_ENABLE();

    /**SPI2 GPIO Configuration
    PC2     ------> SPI2_MISO
    PC3     ------> SPI2_MOSI
    PB10     ------> SPI2_SCK
    */
    GPIO_InitStruct.Pin       = GPIO_PIN_2 | GPIO_PIN_3;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF5_SPI2;
    HAL_GPIO_Init( GPIOC, &GPIO_InitStruct );

    GPIO_InitStruct.Pin       = GPIO_PIN_10;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF5_SPI2;
    HAL_GPIO_Init( GPIOB, &GPIO_InitStruct );
  }
}


void HAL_SPI_MspDeInit(SPI_HandleTypeDef* hspi)
{
  if ( hspi->Instance==SPI2 )
  {
    /* Peripheral clock disable */
    __HAL_RCC_SPI2_CLK_DISABLE();

    /**SPI2 GPIO Configuration
    PC2     ------> SPI2_MISO
    PC3     ------> SPI2_MOSI
    PB10     ------> SPI2_SCK
    */
    HAL_GPIO_DeInit( GPIOC, GPIO_PIN_2 | GPIO_PIN_3 );
    HAL_GPIO_DeInit( GPIOB, GPIO_PIN_10 );
  }
}


static void MX_SPI2_Init(void)
{
  hspi2.Instance               = SPI2;
  hspi2.Init.Mode              = SPI_MODE_MASTER;
  hspi2.Init.Direction         = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize          = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity       = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase          = SPI_PHASE_1EDGE;
  hspi2.Init.NSS               = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_128;
  hspi2.Init.FirstBit          = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode            = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation    = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial     = 10;
  HAL_SPI_Init( &hspi2 );
}


static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  TOUCH_CS_GPIO_CLK_ENABLE();
  TOUCH_INT_GPIO_CLK_ENABLE();

  /* Configure GPIO pin : PB14 */
  GPIO_InitStruct.Pin   = TOUCH_CS_PIN;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init( TOUCH_CS_GPIO_PORT, &GPIO_InitStruct );

  HAL_GPIO_WritePin( TOUCH_CS_GPIO_PORT, TOUCH_CS_PIN, GPIO_PIN_SET );

  /* Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin  = TOUCH_INT_PIN;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init( TOUCH_INT_GPIO_PORT, &GPIO_InitStruct );
}


static uint8_t CmndXPos[ 3 ] = { 0x90, 0x00, 0x00 };
static uint8_t CmndYPos[ 3 ] = { 0xD0, 0x00, 0x00 };

static int XPT2046_ReadTouchPos(uint16_t* aX, uint16_t* aY )
{
  GPIO_PinState pinState;
  uint8_t       data[ 3 ];

  /* read PENIRQ pin (active low) */
  pinState = HAL_GPIO_ReadPin( TOUCH_INT_GPIO_PORT, TOUCH_INT_PIN );

  /* return 0 in case of no touch event */
  if ( pinState )
    return 0;

  /* set chip select (active low) */
  HAL_GPIO_WritePin( TOUCH_CS_GPIO_PORT, TOUCH_CS_PIN, GPIO_PIN_RESET );

  /* X-position: send the command byte and receive two data bytes */
  HAL_SPI_TransmitReceive( &hspi2, &CmndXPos[ 0 ], &data[ 0 ], 3, 1000 );

  /* first data byte contains bits 11...4, second data byte contains bits 3...0 */
  *aX = (uint16_t)data[ 1 ] << 4 | data[ 2 ] >> 4;

  /* Y-position: send the command byte and receive two data bytes */
  HAL_SPI_TransmitReceive( &hspi2, &CmndYPos[ 0 ], &data[ 0 ], 3, 1000 );

  /* first data byte contains bits 11...4, second data byte contains bits 3...0 */
  *aY = (uint16_t)data[ 1 ] << 4 | data[ 2 ] >> 4;

  /* release chip select (active low) */
  HAL_GPIO_WritePin( TOUCH_CS_GPIO_PORT, TOUCH_CS_PIN, GPIO_PIN_SET );

  return 1;
}


/*******************************************************************************
* FUNCTION:
*   XPT2046_Init
*
* DESCRIPTION:
*   The function initializes the SPI hardware and all necessary GPIO in order
*   to intialize the connected touch controller.
*
* ARGUMENTS:
*   aW       - Width of the touch area in pixel.
*   aH       - Height of the touch area in pixel.
*
* RETURN VALUE:
*   If successful, returns != 0.
*
*******************************************************************************/
int XPT2046_Init( uint16_t aW, uint16_t aH )
{
  /* Initialize x and y positions boundaries */
  TsXBoundary = aW;
  TsYBoundary = aH;

  MX_GPIO_Init();
  MX_SPI2_Init();

  return 0;
}


/*******************************************************************************
* FUNCTION:
*   XPT2046_GetTouchState
*
* DESCRIPTION:
*   The function returns the current touch state and touch position.
*
* ARGUMENTS:
*   aState   - Pointer to structure to return state and position.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void XPT2046_GetTouchState( TS_StateTypeDef* aState )
{
  uint16_t xr, yr;
  int32_t x, y;
  static int32_t filterX[ NO_OF_SAMPLES ];
  static int32_t filterY[ NO_OF_SAMPLES ];
  int i;

  /* read current touch position and state */
  aState->TouchDetected = XPT2046_ReadTouchPos( &xr, &yr );
  if ( aState->TouchDetected )
  {
    //xprintf( "x = %d, y = %d\n", xr, yr );

    /* change x/y values if necessary */
    #if CHANGE_XY == 1
      uint16_t tmp = xr;
      xr = yr;
      yr = tmp;
    #endif

    /* convert touch pos into screen X-pos by using simple calibration constants */
    #if ( X_MAX > X_MIN )
      x = ((int32_t)( xr - X_MIN ) * TsXBoundary ) / ( X_MAX - X_MIN );
    #else
      x = ((int32_t)( X_MIN - xr ) * TsXBoundary ) / ( X_MIN - X_MAX );
    #endif

    /* convert touch pos into screen Y-pos by using simple calibration constants */
    #if ( Y_MAX > Y_MIN )
      y = ((int32_t)( yr - Y_MIN ) * TsYBoundary ) / ( Y_MAX - Y_MIN );
    #else
      y = ((int32_t)( Y_MIN - yr ) * TsYBoundary ) / ( Y_MIN - Y_MAX );
    #endif

    /* correct limits */
    if ( x < 0 ) x = 0;
    if ( y < 0 ) y = 0;
    if ( x >= TsXBoundary ) x = TsXBoundary - 1;
    if ( y >= TsYBoundary ) y = TsYBoundary - 1;

    /* take first touch value as filter start value */
    if (( filterX[ 0 ] < 0 ) || ( filterY[ 0 ] < 0 ))
    {
      /* fill entire array with start value */
      for ( i = 0; i < NO_OF_SAMPLES; i++ )
      {
        filterX[ i ] = x;
        filterY[ i ] = y;
      }
    }
    else
    {
      /* move content of filter array */
      for ( i = 0; i < NO_OF_SAMPLES - 1; i++ )
      {
        filterX[ i ] = filterX[ i + 1 ];
        filterY[ i ] = filterY[ i + 1 ];
      }
      /* store new position at the end of the array */
      filterX[ NO_OF_SAMPLES - 1 ] = x;
      filterY[ NO_OF_SAMPLES - 1 ] = y;
    }

    /* build an avarage value about all values */
    for ( i = 0; i < NO_OF_SAMPLES - 1; i++ )
    {
      x += filterX[ i ];
      y += filterY[ i ];
    }
    x /= NO_OF_SAMPLES;
    y /= NO_OF_SAMPLES;

    /* update the X position */
    aState->X = (uint16_t)x;

    /* update the Y position */
    aState->Y = (uint16_t)y;
  }
  else
  {
    /* sign the first filter value as invalid */
    filterX[ 0 ] = -1;
    filterY[ 0 ] = -1;
  }
}


/* msy */

/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is delivered "as is" and shows the usage of other software
* components. It is provided as an example software which is intended to be
* modified and extended according to particular requirements.
*
* TARA Systems hereby disclaims all warranties and conditions with regard to the
* software, including all implied warranties and conditions of merchantability
* and non-infringement of any third party IPR or other rights which may result
* from the use or the inability to use the software.
*
********************************************************************************
*
* DESCRIPTION:
*   This file contains the necessary initialization of the ILI9325 display
*   controller and the necessary function to update a rectangular area of the
*   screen from an Embedded Wizard UI application.
*   The data transfer is done by using the hardware FSMC controller via the
*   16bit 8080 interface. The color format of the display is RGB565.
*
*   This driver assumes the following layout of the interface:
*   Data lines D0...D15 (FSMC):
*     D0   - PD14
*     D1   - PD15
*     D2   - PD0
*     D3   - PD1
*     D4   - PE7
*     D5   - PE8
*     D6   - PE9
*     D7   - PE10
*     D8   - PE11
*     D9   - PE12
*     D10  - PE13
*     D11  - PE14
*     D12  - PE15
*     D13  - PD8
*     D14  - PD9
*     D15  - PD10
*   Control lines (FSCM):
*     /CS  - PD7   (FSMC_NE1) => chip select, low active
*     /RD  - PD4   (FSMC_NOE) => read access, low active
*     /WR  - PD5   (FSMC_NWE) => write access, low active
*     DC   - PE3   (A19)      => register select (data/command)
*   Additional control lines:
*     /RST - PD3              => reset of LCD module, low active
*     BL   - PD13             => backlight
*
*   This module is just a template - adapt pin configuration and timing (!)
*   according your hardware layout and hardware constraints.
*   Adjust device parameters, initialization and gamma correction values
*   according your display and your needs.
*   This driver was tested on a HY32D display module (3,2" TFT 240x320).
*
*******************************************************************************/

#include "stm32f4xx_hal.h"

#include "ili9325_16bit_fsmc.h"

/* LCD reset pin */
#define LCD_RESET_PIN                   GPIO_PIN_3
#define LCD_RESET_GPIO_PORT             GPIOD
#define LCD_RESET_GPIO_CLK_ENABLE()     __HAL_RCC_GPIOD_CLK_ENABLE()
#define LCD_RESET_GPIO_CLK_DISABLE()    __HAL_RCC_GPIOD_CLK_DISABLE()

/* backlight control pin */
#define LCD_BL_CTRL_PIN                 GPIO_PIN_5
#define LCD_BL_CTRL_GPIO_PORT           GPIOF
#define LCD_BL_CTRL_GPIO_CLK_ENABLE()   __HAL_RCC_GPIOF_CLK_ENABLE()
#define LCD_BL_CTRL_GPIO_CLK_DISABLE()  __HAL_RCC_GPIOF_CLK_DISABLE()

/* FSMC addresses for command and data port of ILI9325 */
#define ILI9325_Cmnd (__IO uint16_t*)((uint32_t)0x60000000)
#define ILI9325_Data (__IO uint16_t*)((uint32_t)0x60100000)

/* display specific settings */
#define DISPLAY_PIXEL_WIDTH             ((uint16_t)240)
#define DISPLAY_PIXEL_HEIGHT            ((uint16_t)320)

/* ILI9325 commands */
#define ILI9325_START_OSCILLATION       0x00
#define ILI9325_DRIVER_CODE_READ        0x00
#define ILI9325_DRIVER_OUTPUT_CTRL_1    0x01
#define ILI9325_LCD_DRIVING_CTRL        0x02
#define ILI9325_ENTRY_MODE              0x03
#define ILI9325_RESIZE_CTRL             0x04
#define ILI9325_DISPLAY_CTRL_1          0x07
#define ILI9325_DISPLAY_CTRL_2          0x08
#define ILI9325_DISPLAY_CTRL_3          0x09
#define ILI9325_DISPLAY_CTRL_4          0x0A
#define ILI9325_RGB_DISPLAY_INTERFACE_1 0x0C
#define ILI9325_FRAME_MARKER_POSITION   0x0D
#define ILI9325_RGB_DISPLAY_INTERFACE_2 0x0F
#define ILI9325_POWER_CTRL_1            0x10
#define ILI9325_POWER_CTRL_2            0x11
#define ILI9325_POWER_CTRL_3            0x12
#define ILI9325_POWER_CTRL_4            0x13
#define ILI9325_HORZ_GRAM_ADDRESS_SET   0x20
#define ILI9325_VERT_GRAM_ADDRESS_SET   0x21
#define ILI9325_WRITE_DATA_TO_GRAM      0x22
#define ILI9325_POWER_CTRL_7            0x29
#define ILI9325_FRAME_RATE_AND_COLOR    0x2B
#define ILI9325_GAMMA_CTRL_1            0x30
#define ILI9325_GAMMA_CTRL_2            0x31
#define ILI9325_GAMMA_CTRL_3            0x32
#define ILI9325_GAMMA_CTRL_4            0x35
#define ILI9325_GAMMA_CTRL_5            0x36
#define ILI9325_GAMMA_CTRL_6            0x37
#define ILI9325_GAMMA_CTRL_7            0x38
#define ILI9325_GAMMA_CTRL_8            0x39
#define ILI9325_GAMMA_CTRL_9            0x3C
#define ILI9325_GAMMA_CTRL_10           0x3D
#define ILI9325_HORZ_ADDRESS_START      0x50
#define ILI9325_HORZ_ADDRESS_END        0x51
#define ILI9325_VERT_ADDRESS_START      0x52
#define ILI9325_VERT_ADDRESS_END        0x53
#define ILI9325_DRIVER_OUTPUT_CTRL_2    0x60
#define ILI9325_BASE_IMAGE_DISPLAY      0x61
#define ILI9325_VERT_SCROLL_CTRL        0x6A
#define ILI9325_PART_IMAGE_1_POSITION   0x80
#define ILI9325_PART_IMGAE_1_START      0x81
#define ILI9325_PART_IMGAE_1_END        0x82
#define ILI9325_PART_IMAGE_2_POSITION   0x83
#define ILI9325_PART_IMGAE_2_START      0x84
#define ILI9325_PART_IMGAE_2_END        0x85
#define ILI9325_PANEL_INTERFACE_CTRL_1  0x90
#define ILI9325_PANEL_INTERFACE_CTRL_2  0x92
#define ILI9325_PANEL_INTERFACE_CTRL_4  0x95
#define ILI9325_OTP_VCM_PROG            0xA1
#define ILI9325_OTM_VCM_STATUS          0xA2
#define ILI9325_OTM_PROG_ID_KEY         0xA3


/*************************** FMC Routines ************************************/
static void FMC_BANK1_MspInit(void)
{
  GPIO_InitTypeDef gpio;

  /* Enable FSMC clock */
  __HAL_RCC_FSMC_CLK_ENABLE();

  /* Enable GPIOs clock */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();

  /* Common GPIO configuration */
  gpio.Mode      = GPIO_MODE_AF_PP;
  gpio.Pull      = GPIO_PULLUP;
  gpio.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
  gpio.Alternate = GPIO_AF12_FSMC;

  /* GPIOD configuration */
  gpio.Pin       = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_4 | GPIO_PIN_5
                 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10
                 | GPIO_PIN_14 | GPIO_PIN_15;
  HAL_GPIO_Init( GPIOD, &gpio );

  /* GPIOE configuration */
  gpio.Pin       = GPIO_PIN_3 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9
                 | GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13
                 | GPIO_PIN_14 | GPIO_PIN_15;
  HAL_GPIO_Init( GPIOE, &gpio );
}


static void FMC_BANK1_Init(void)
{
  SRAM_HandleTypeDef hsram;
  FMC_NORSRAM_TimingTypeDef sram_timing_rd;
  FMC_NORSRAM_TimingTypeDef sram_timing_wr;

  /* configure IPs */
  hsram.Instance                       = FSMC_NORSRAM_DEVICE;
  hsram.Extended                       = FSMC_NORSRAM_EXTENDED_DEVICE;

  /* timing for READING */
  sram_timing_rd.AddressSetupTime      = 9;
  sram_timing_rd.AddressHoldTime       = 1;
  sram_timing_rd.DataSetupTime         = 36;
  sram_timing_rd.BusTurnAroundDuration = 1;
  sram_timing_rd.CLKDivision           = 2;
  sram_timing_rd.DataLatency           = 2;
  sram_timing_rd.AccessMode            = FSMC_ACCESS_MODE_A;

  /* timing for WRITTING */
  sram_timing_wr.AddressSetupTime      = 1;
  sram_timing_wr.AddressHoldTime       = 1;
  sram_timing_wr.DataSetupTime         = 7;
  sram_timing_wr.BusTurnAroundDuration = 0;
  sram_timing_wr.CLKDivision           = 2;
  sram_timing_wr.DataLatency           = 2;
  sram_timing_wr.AccessMode            = FSMC_ACCESS_MODE_A;

  hsram.Init.NSBank                    = FSMC_NORSRAM_BANK1;
  hsram.Init.DataAddressMux            = FSMC_DATA_ADDRESS_MUX_DISABLE;
  hsram.Init.MemoryType                = FSMC_MEMORY_TYPE_SRAM;
  hsram.Init.MemoryDataWidth           = FSMC_NORSRAM_MEM_BUS_WIDTH_16;
  hsram.Init.BurstAccessMode           = FSMC_BURST_ACCESS_MODE_DISABLE;
  hsram.Init.WaitSignalPolarity        = FSMC_WAIT_SIGNAL_POLARITY_LOW;
  hsram.Init.WrapMode                  = FSMC_WRAP_MODE_DISABLE;
  hsram.Init.WaitSignalActive          = FSMC_WAIT_TIMING_BEFORE_WS;
  hsram.Init.WriteOperation            = FSMC_WRITE_OPERATION_ENABLE;
  hsram.Init.WaitSignal                = FSMC_WAIT_SIGNAL_DISABLE;
  hsram.Init.ExtendedMode              = FSMC_EXTENDED_MODE_DISABLE;
  hsram.Init.AsynchronousWait          = FSMC_ASYNCHRONOUS_WAIT_DISABLE;
  hsram.Init.WriteBurst                = FSMC_WRITE_BURST_DISABLE;
  hsram.Init.PageSize                  = FSMC_PAGE_SIZE_NONE;
  hsram.Init.ContinuousClock           = FSMC_CONTINUOUS_CLOCK_SYNC_ONLY;

  /* initialize the SRAM controller */
  FMC_BANK1_MspInit();
  HAL_SRAM_Init( &hsram, &sram_timing_rd, &sram_timing_wr );
}


/* helper function to initialize reset and backlight pins of LCD and to perform
   proper reset of display */
static void ILI9325_ResetDisplay()
{
  GPIO_InitTypeDef gpio;

  /* enable clock for LCD reset pin */
  LCD_RESET_GPIO_CLK_ENABLE();

  /* configure GPIO for LCD reset pin */
  gpio.Pin   = LCD_RESET_PIN;
  gpio.Pull  = GPIO_NOPULL;
  gpio.Speed = GPIO_SPEED_FAST;
  gpio.Mode  = GPIO_MODE_OUTPUT_PP;
  HAL_GPIO_Init( LCD_RESET_GPIO_PORT, &gpio );

  /* apply hardware reset */
  HAL_GPIO_WritePin( LCD_RESET_GPIO_PORT, LCD_RESET_PIN, GPIO_PIN_RESET );
  HAL_Delay( 100 );  /* reset signal asserted during 100ms */
  HAL_GPIO_WritePin( LCD_RESET_GPIO_PORT, LCD_RESET_PIN, GPIO_PIN_SET );
  HAL_Delay( 10 );  /* reset signal released during 10ms */

  /* enable clock for LCD backlight control pin */
  LCD_BL_CTRL_GPIO_CLK_ENABLE();

  /* configure GPIO for LCD backlight control pin */
  gpio.Pin  = LCD_BL_CTRL_PIN;
  gpio.Mode = GPIO_MODE_OUTPUT_PP;
  HAL_GPIO_Init( LCD_BL_CTRL_GPIO_PORT, &gpio );

  /* switch backlight on */
  HAL_GPIO_WritePin( LCD_BL_CTRL_GPIO_PORT, LCD_BL_CTRL_PIN, GPIO_PIN_SET );
}


/* helper function to set a command register value */
static void ILI9325_WriteReg( uint8_t aReg, uint16_t aValue )
{
  *ILI9325_Cmnd = aReg;
  *ILI9325_Data = aValue;
}


/* helper function to read a data value */
static uint16_t ILI9325_ReadData( void )
{
  return *ILI9325_Data;
}


/*******************************************************************************
* FUNCTION:
*   ILI9325_Init
*
* DESCRIPTION:
*   The function initializes the FSMC hardware and all necessary GPIO in order
*   to reset and intialize the connected display hardware.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void ILI9325_Init( void )
{
  /* initialize FSMC hardware (16bit, 8080 interface) */
  FMC_BANK1_Init();

  /* perform reset of LCD */
  ILI9325_ResetDisplay();

  /* start oscillation */
  ILI9325_WriteReg( ILI9325_START_OSCILLATION, 0x0001 );

  /* select shift direction, wave control, orientation */
  ILI9325_WriteReg( ILI9325_DRIVER_OUTPUT_CTRL_1, 0x0100 );
  ILI9325_WriteReg( ILI9325_LCD_DRIVING_CTRL, 0x0700 );
  ILI9325_WriteReg( ILI9325_ENTRY_MODE, 0x1030 );

  /* select 1:1 scaling */
  ILI9325_WriteReg( ILI9325_RESIZE_CTRL, 0x0000 );

  ILI9325_WriteReg( ILI9325_DISPLAY_CTRL_2, 0x0207 );
  ILI9325_WriteReg( ILI9325_DISPLAY_CTRL_3, 0x0000 );
  ILI9325_WriteReg( ILI9325_DISPLAY_CTRL_4, 0x0000 );
  ILI9325_WriteReg( ILI9325_RGB_DISPLAY_INTERFACE_1, 0x0001 );
  ILI9325_WriteReg( ILI9325_FRAME_MARKER_POSITION, 0x0000 );
  ILI9325_WriteReg( ILI9325_RGB_DISPLAY_INTERFACE_2, 0x0000 );

  /* power on sequence */
  ILI9325_WriteReg( ILI9325_POWER_CTRL_1, 0x0000 );
  ILI9325_WriteReg( ILI9325_POWER_CTRL_2, 0x0007 );
  ILI9325_WriteReg( ILI9325_POWER_CTRL_3, 0x0000 );
  ILI9325_WriteReg( ILI9325_POWER_CTRL_4, 0x0000 );
  HAL_Delay( 50 );
  ILI9325_WriteReg( ILI9325_POWER_CTRL_1, 0x1590 );
  ILI9325_WriteReg( ILI9325_POWER_CTRL_2, 0x0227 );
  HAL_Delay( 50 );
  ILI9325_WriteReg( ILI9325_POWER_CTRL_3, 0x009C );
  HAL_Delay( 50 );
  ILI9325_WriteReg( ILI9325_POWER_CTRL_4, 0x1900 );
  ILI9325_WriteReg( ILI9325_POWER_CTRL_7, 0x0023);
  ILI9325_WriteReg( ILI9325_FRAME_RATE_AND_COLOR, 0x000A );
  HAL_Delay( 50 );

  /* set display dimension */
	ILI9325_WriteReg( ILI9325_HORZ_ADDRESS_START, 0 );
	ILI9325_WriteReg( ILI9325_HORZ_ADDRESS_END, DISPLAY_PIXEL_WIDTH - 1 );
	ILI9325_WriteReg( ILI9325_VERT_ADDRESS_START, 0 );
	ILI9325_WriteReg( ILI9325_VERT_ADDRESS_END, DISPLAY_PIXEL_HEIGHT - 1 );

  ILI9325_WriteReg( ILI9325_DRIVER_OUTPUT_CTRL_2, 0xA700 );
  ILI9325_WriteReg( ILI9325_BASE_IMAGE_DISPLAY, 0x0001 );
  ILI9325_WriteReg( ILI9325_VERT_SCROLL_CTRL, 0x0000 );

  ILI9325_WriteReg( ILI9325_PART_IMAGE_1_POSITION, 0x0000 );
  ILI9325_WriteReg( ILI9325_PART_IMGAE_1_START, 0x0000 );
  ILI9325_WriteReg( ILI9325_PART_IMGAE_1_END, 0x0000 );
  ILI9325_WriteReg( ILI9325_PART_IMAGE_2_POSITION, 0x0000 );
  ILI9325_WriteReg( ILI9325_PART_IMGAE_2_START, 0x0000 );
  ILI9325_WriteReg( ILI9325_PART_IMGAE_2_END, 0x0000 );

  ILI9325_WriteReg( ILI9325_PANEL_INTERFACE_CTRL_1, 0x0010 );
  ILI9325_WriteReg( ILI9325_PANEL_INTERFACE_CTRL_2, 0x0600);
  ILI9325_WriteReg( 0x93, 0x0003 );
  ILI9325_WriteReg( ILI9325_PANEL_INTERFACE_CTRL_4, 0x0110 );
  ILI9325_WriteReg( 0x97, 0x0000 );
  ILI9325_WriteReg( 0x98, 0x0000 );

  /* switch display on */
  ILI9325_WriteReg( ILI9325_DISPLAY_CTRL_1, 0x0133 );
  HAL_Delay( 50 );
}


/*******************************************************************************
* FUNCTION:
*   ILI9325_ReadID
*
* DESCRIPTION:
*   The function assumes a connected and intialized ILI9325 display and tries
*   to read its ID.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   If successful, the function returns the ID of the display - 0 otherwise.
*
*******************************************************************************/
uint16_t ILI9325_ReadID(void)
{
  uint16_t result;

  /* send command */
  *ILI9325_Cmnd = ILI9325_DRIVER_CODE_READ;

  /* read register value */
  result = ILI9325_ReadData();

  return result;
}


/*******************************************************************************
* FUNCTION:
*   ILI9325_SetDataPosition
*
* DESCRIPTION:
*   The function sets the destination position within the framebuffer of the
*   display according the given x/y position.
*
* ARGUMENTS:
*   aX       - Horizontal position for next write access.
*   aY       - Vertical position for next write access.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void ILI9325_SetDataPosition( uint16_t aX, uint16_t aY )
{
  /* set the GRAM window to entire display size */
  ILI9325_WriteReg( ILI9325_HORZ_ADDRESS_START, 0x0000 );
  ILI9325_WriteReg( ILI9325_HORZ_ADDRESS_END, DISPLAY_PIXEL_WIDTH - 1 );
  ILI9325_WriteReg( ILI9325_VERT_ADDRESS_START, 0x0000 );
  ILI9325_WriteReg( ILI9325_VERT_ADDRESS_END, DISPLAY_PIXEL_HEIGHT - 1 );

  ILI9325_WriteReg( ILI9325_HORZ_GRAM_ADDRESS_SET, aX );
  ILI9325_WriteReg( ILI9325_VERT_GRAM_ADDRESS_SET, aY );

  /* set command to make subsequent data transfers */
  *ILI9325_Cmnd = ILI9325_WRITE_DATA_TO_GRAM;
}


/*******************************************************************************
* FUNCTION:
*   ILI9325_SetDataWindow
*
* DESCRIPTION:
*   The function sets the destination position and size within the framebuffer
*   of the display according the given rectangle.
*
* ARGUMENTS:
*   aX       - Horizontal position for next write access.
*   aY       - Vertical position for next write access.
*   aW       - Width of the data window in pixel.
*   aH       - Height of the data window in pixel.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void ILI9325_SetDataWindow( uint16_t aX, uint16_t aY, uint16_t aW, uint16_t aH )
{
  int xEnd = aX + aW - 1;
  int yEnd = aY + aH - 1;

  if ( xEnd >= DISPLAY_PIXEL_WIDTH )
    xEnd = DISPLAY_PIXEL_WIDTH - 1;
  if ( yEnd >= DISPLAY_PIXEL_HEIGHT )
    yEnd = DISPLAY_PIXEL_HEIGHT - 1;

  /* set the GRAM window to entire display size */
  ILI9325_WriteReg( ILI9325_HORZ_ADDRESS_START, aX );
  ILI9325_WriteReg( ILI9325_HORZ_ADDRESS_END, xEnd );
  ILI9325_WriteReg( ILI9325_VERT_ADDRESS_START, aY );
  ILI9325_WriteReg( ILI9325_VERT_ADDRESS_END, yEnd );

  ILI9325_WriteReg( ILI9325_HORZ_GRAM_ADDRESS_SET, aX );
  ILI9325_WriteReg( ILI9325_VERT_GRAM_ADDRESS_SET, aY );

  /* set command to make subsequent data transfers */
  *ILI9325_Cmnd = ILI9325_WRITE_DATA_TO_GRAM;
}


/*******************************************************************************
* FUNCTION:
*   ILI9325_WriteData
*
* DESCRIPTION:
*   Write a single data word to the ILI9325 display.
*
* ARGUMENTS:
*   aData    - 16 bit value to be sent to the ILI9325 display.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void ILI9325_WriteData( uint16_t aData )
{
  *ILI9325_Data = aData;
}


/*******************************************************************************
* FUNCTION:
*   ILI9325_WriteMultipleData
*
* DESCRIPTION:
*   Write a sequence of data words to the ILI9325 display.
*
* ARGUMENTS:
*   aData    - pointer to 16 bit values to be sent to the ILI9325 display.
*   aSize    - Number of data values to be sent.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void ILI9325_WriteMultipleData( uint16_t* aData, uint32_t aSize )
{
  while ( aSize-- )
    *ILI9325_Data = *aData++;
}


/* msy */

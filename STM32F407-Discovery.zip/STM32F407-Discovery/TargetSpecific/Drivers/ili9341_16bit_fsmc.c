/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is delivered "as is" and shows the usage of other software
* components. It is provided as an example software which is intended to be
* modified and extended according to particular requirements.
*
* TARA Systems hereby disclaims all warranties and conditions with regard to the
* software, including all implied warranties and conditions of merchantability
* and non-infringement of any third party IPR or other rights which may result
* from the use or the inability to use the software.
*
********************************************************************************
*
* DESCRIPTION:
*   This file contains the necessary initialization of the ILI9341 display
*   controller and the necessary function to update a rectangular area of the
*   screen from an Embedded Wizard UI application.
*   The data transfer is done by using the hardware FSMC controller via the
*   16bit 8080 interface. The color format of the display is RGB565.
*
*   This driver assumes the following layout of the interface:
*   Data lines D0...D15 (FSMC):
*     D0   - PD14
*     D1   - PD15
*     D2   - PD0
*     D3   - PD1
*     D4   - PE7
*     D5   - PE8
*     D6   - PE9
*     D7   - PE10
*     D8   - PE11
*     D9   - PE12
*     D10  - PE13
*     D11  - PE14
*     D12  - PE15
*     D13  - PD8
*     D14  - PD9
*     D15  - PD10
*   Control lines (FSCM):
*     /CS  - PD7   (FSMC_NE1) => chip select, low active
*     /RD  - PD4   (FSMC_NOE) => read access, low active
*     /WR  - PD5   (FSMC_NWE) => write access, low active
*     DC   - PE3   (A19)      => register select (data/command)
*   Additional control lines:
*     /RST - PD3              => reset of LCD module, low active
*
*   This module is just a template - adapt pin configuration and timing (!)
*   according your hardware layout and hardware constraints.
*   Adjust device parameters, initialization and gamma correction values
*   according your display and your needs.
*   This driver was tested on a TFT_320QVT_9341 display module (3,2" TFT 240x320).
*
*******************************************************************************/

#include "stm32f4xx_hal.h"

#include "ili9341_16bit_fsmc.h"

/* LCD reset pin */
#define LCD_RESET_PIN                   GPIO_PIN_3
#define LCD_RESET_GPIO_PORT             GPIOD
#define LCD_RESET_GPIO_CLK_ENABLE()     __HAL_RCC_GPIOD_CLK_ENABLE()
#define LCD_RESET_GPIO_CLK_DISABLE()    __HAL_RCC_GPIOD_CLK_DISABLE()

/* backlight control pin */
//#define LCD_BL_CTRL_PIN                 GPIO_PIN_5
//#define LCD_BL_CTRL_GPIO_PORT           GPIOF
//#define LCD_BL_CTRL_GPIO_CLK_ENABLE()   __HAL_RCC_GPIOF_CLK_ENABLE()
//#define LCD_BL_CTRL_GPIO_CLK_DISABLE()  __HAL_RCC_GPIOF_CLK_DISABLE()

/* FSMC addresses for command and data port of ILI9341 */
#define ILI9341_Cmnd (__IO uint16_t*)((uint32_t)0x60000000)
#define ILI9341_Data (__IO uint16_t*)((uint32_t)0x60100000)

/* display specific settings */
#define DISPLAY_PIXEL_WIDTH             ((uint16_t)240)
#define DISPLAY_PIXEL_HEIGHT            ((uint16_t)320)

/* ILI9341 commands */
#define ILI9341_SWRESET                 0x01   /* Software Reset */
#define ILI9341_READ_DISPLAY_ID         0x04   /* Read display identification information */
#define ILI9341_RDDST                   0x09   /* Read Display Status */
#define ILI9341_RDDPM                   0x0A   /* Read Display Power Mode */
#define ILI9341_RDDMADCTL               0x0B   /* Read Display MADCTL */
#define ILI9341_RDDCOLMOD               0x0C   /* Read Display Pixel Format */
#define ILI9341_RDDIM                   0x0D   /* Read Display Image Format */
#define ILI9341_RDDSM                   0x0E   /* Read Display Signal Mode */
#define ILI9341_RDDSDR                  0x0F   /* Read Display Self-Diagnostic Result */
#define ILI9341_SPLIN                   0x10   /* Enter Sleep Mode */
#define ILI9341_SLEEP_OUT               0x11   /* Sleep out register */
#define ILI9341_PTLON                   0x12   /* Partial Mode ON */
#define ILI9341_NORMAL_MODE_ON          0x13   /* Normal Display Mode ON */
#define ILI9341_DINVOFF                 0x20   /* Display Inversion OFF */
#define ILI9341_DINVON                  0x21   /* Display Inversion ON */
#define ILI9341_GAMMA                   0x26   /* Gamma register */
#define ILI9341_DISPLAY_OFF             0x28   /* Display off register */
#define ILI9341_DISPLAY_ON              0x29   /* Display on register */
#define ILI9341_COLUMN_ADDR             0x2A   /* Colomn address register */
#define ILI9341_PAGE_ADDR               0x2B   /* Page address register */
#define ILI9341_GRAM                    0x2C   /* GRAM register */
#define ILI9341_RGBSET                  0x2D   /* Color SET */
#define ILI9341_RAMRD                   0x2E   /* Memory Read */
#define ILI9341_PLTAR                   0x30   /* Partial Area */
#define ILI9341_VSCRDEF                 0x33   /* Vertical Scrolling Definition */
#define ILI9341_TEOFF                   0x34   /* Tearing Effect Line OFF */
#define ILI9341_TEON                    0x35   /* Tearing Effect Line ON */
#define ILI9341_MAC                     0x36   /* Memory Access Control register*/
#define ILI9341_VSCRSADD                0x37   /* Vertical Scrolling Start Address */
#define ILI9341_IDMOFF                  0x38   /* Idle Mode OFF */
#define ILI9341_IDMON                   0x39   /* Idle Mode ON */
#define ILI9341_PIXEL_FORMAT            0x3A   /* Pixel Format register */
#define ILI9341_WRITE_MEM_CONTINUE      0x3C   /* Write Memory Continue */
#define ILI9341_READ_MEM_CONTINUE       0x3E   /* Read Memory Continue */
#define ILI9341_SET_TEAR_SCANLINE       0x44   /* Set Tear Scanline */
#define ILI9341_GET_SCANLINE            0x45   /* Get Scanline */
#define ILI9341_WDB                     0x51   /* Write Brightness Display register */
#define ILI9341_RDDISBV                 0x52   /* Read Display Brightness */
#define ILI9341_WCD                     0x53   /* Write Control Display register*/
#define ILI9341_RDCTRLD                 0x54   /* Read CTRL Display */
#define ILI9341_WRCABC                  0x55   /* Write Content Adaptive Brightness Control */
#define ILI9341_RDCABC                  0x56   /* Read Content Adaptive Brightness Control */
#define ILI9341_WRITE_CABC              0x5E   /* Write CABC Minimum Brightness */
#define ILI9341_READ_CABC               0x5F   /* Read CABC Minimum Brightness */
#define ILI9341_READ_ID1                0xDA   /* Read ID1 */
#define ILI9341_READ_ID2                0xDB   /* Read ID2 */
#define ILI9341_READ_ID3                0xDC   /* Read ID3 */
#define ILI9341_RGB_INTERFACE           0xB0   /* RGB Interface Signal Control */
#define ILI9341_FRMCTR1                 0xB1   /* Frame Rate Control (In Normal Mode) */
#define ILI9341_FRMCTR2                 0xB2   /* Frame Rate Control (In Idle Mode) */
#define ILI9341_FRMCTR3                 0xB3   /* Frame Rate Control (In Partial Mode) */
#define ILI9341_INVTR                   0xB4   /* Display Inversion Control */
#define ILI9341_BPC                     0xB5   /* Blanking Porch Control register */
#define ILI9341_DFC                     0xB6   /* Display Function Control register */
#define ILI9341_ETMOD                   0xB7   /* Entry Mode Set */
#define ILI9341_BACKLIGHT1              0xB8   /* Backlight Control 1 */
#define ILI9341_BACKLIGHT2              0xB9   /* Backlight Control 2 */
#define ILI9341_BACKLIGHT3              0xBA   /* Backlight Control 3 */
#define ILI9341_BACKLIGHT4              0xBB   /* Backlight Control 4 */
#define ILI9341_BACKLIGHT5              0xBC   /* Backlight Control 5 */
#define ILI9341_BACKLIGHT7              0xBE   /* Backlight Control 7 */
#define ILI9341_BACKLIGHT8              0xBF   /* Backlight Control 8 */
#define ILI9341_POWER1                  0xC0   /* Power Control 1 register */
#define ILI9341_POWER2                  0xC1   /* Power Control 2 register */
#define ILI9341_VCOM1                   0xC5   /* VCOM Control 1 register */
#define ILI9341_VCOM2                   0xC7   /* VCOM Control 2 register */
#define ILI9341_NVMWR                   0xD0   /* NV Memory Write */
#define ILI9341_NVMPKEY                 0xD1   /* NV Memory Protection Key */
#define ILI9341_RDNVM                   0xD2   /* NV Memory Status Read */
#define ILI9341_READ_ID4                0xD3   /* Read ID4 */
#define ILI9341_PGAMMA                  0xE0   /* Positive Gamma Correction register */
#define ILI9341_NGAMMA                  0xE1   /* Negative Gamma Correction register */
#define ILI9341_DGAMCTRL1               0xE2   /* Digital Gamma Control 1 */
#define ILI9341_DGAMCTRL2               0xE3   /* Digital Gamma Control 2 */
#define ILI9341_INTERFACE               0xF6   /* Interface control register */
#define ILI9341_POWERA                  0xCB   /* Power control A register */
#define ILI9341_POWERB                  0xCF   /* Power control B register */
#define ILI9341_DTCA                    0xE8   /* Driver timing control A */
#define ILI9341_DTCB                    0xEA   /* Driver timing control B */
#define ILI9341_POWER_SEQ               0xED   /* Power on sequence register */
#define ILI9341_3GAMMA_EN               0xF2   /* 3 Gamma enable register */
#define ILI9341_PRC                     0xF7   /* Pump ratio control register */

/* Size of read registers */
#define ILI9341_READ_ID4_SIZE           3      /* Size of Read ID4 */



/*************************** FMC Routines ************************************/
static void FMC_BANK1_MspInit(void)
{
  GPIO_InitTypeDef gpio;

  /* Enable FSMC clock */
  __HAL_RCC_FSMC_CLK_ENABLE();

  /* Enable GPIOs clock */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();

  /* Common GPIO configuration */
  gpio.Mode      = GPIO_MODE_AF_PP;
  gpio.Pull      = GPIO_PULLUP;
  gpio.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
  gpio.Alternate = GPIO_AF12_FSMC;

  /* GPIOD configuration */
  gpio.Pin       = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_4 | GPIO_PIN_5
                 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10
                 | GPIO_PIN_14 | GPIO_PIN_15;
  HAL_GPIO_Init( GPIOD, &gpio );

  /* GPIOE configuration */
  gpio.Pin       = GPIO_PIN_3 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9
                 | GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13
                 | GPIO_PIN_14 | GPIO_PIN_15;
  HAL_GPIO_Init( GPIOE, &gpio );
}


static void FMC_BANK1_Init(void)
{
  SRAM_HandleTypeDef hsram;
  FMC_NORSRAM_TimingTypeDef sram_timing_rd;
  FMC_NORSRAM_TimingTypeDef sram_timing_wr;

  /* configure IPs */
  hsram.Instance                       = FSMC_NORSRAM_DEVICE;
  hsram.Extended                       = FSMC_NORSRAM_EXTENDED_DEVICE;

  /* timing for READING */
  sram_timing_rd.AddressSetupTime      = 9;
  sram_timing_rd.AddressHoldTime       = 1;
  sram_timing_rd.DataSetupTime         = 36;
  sram_timing_rd.BusTurnAroundDuration = 1;
  sram_timing_rd.CLKDivision           = 2;
  sram_timing_rd.DataLatency           = 2;
  sram_timing_rd.AccessMode            = FSMC_ACCESS_MODE_A;

  /* timing for WRITTING */
  sram_timing_wr.AddressSetupTime      = 1;
  sram_timing_wr.AddressHoldTime       = 1;
  sram_timing_wr.DataSetupTime         = 7;
  sram_timing_wr.BusTurnAroundDuration = 0;
  sram_timing_wr.CLKDivision           = 2;
  sram_timing_wr.DataLatency           = 2;
  sram_timing_wr.AccessMode            = FSMC_ACCESS_MODE_A;

  hsram.Init.NSBank                    = FSMC_NORSRAM_BANK1;
  hsram.Init.DataAddressMux            = FSMC_DATA_ADDRESS_MUX_DISABLE;
  hsram.Init.MemoryType                = FSMC_MEMORY_TYPE_SRAM;
  hsram.Init.MemoryDataWidth           = FSMC_NORSRAM_MEM_BUS_WIDTH_16;
  hsram.Init.BurstAccessMode           = FSMC_BURST_ACCESS_MODE_DISABLE;
  hsram.Init.WaitSignalPolarity        = FSMC_WAIT_SIGNAL_POLARITY_LOW;
  hsram.Init.WrapMode                  = FSMC_WRAP_MODE_DISABLE;
  hsram.Init.WaitSignalActive          = FSMC_WAIT_TIMING_BEFORE_WS;
  hsram.Init.WriteOperation            = FSMC_WRITE_OPERATION_ENABLE;
  hsram.Init.WaitSignal                = FSMC_WAIT_SIGNAL_DISABLE;
  hsram.Init.ExtendedMode              = FSMC_EXTENDED_MODE_DISABLE;
  hsram.Init.AsynchronousWait          = FSMC_ASYNCHRONOUS_WAIT_DISABLE;
  hsram.Init.WriteBurst                = FSMC_WRITE_BURST_DISABLE;
  hsram.Init.PageSize                  = FSMC_PAGE_SIZE_NONE;
  hsram.Init.ContinuousClock           = FSMC_CONTINUOUS_CLOCK_SYNC_ONLY;

  /* initialize the SRAM controller */
  FMC_BANK1_MspInit();
  HAL_SRAM_Init( &hsram, &sram_timing_rd, &sram_timing_wr );
}


/* helper function to initialize reset and backlight pins of LCD and to perform
   proper reset of display */
static void ILI9341_ResetDisplay()
{
  GPIO_InitTypeDef gpio;

  /* enable clock for LCD reset pin */
  LCD_RESET_GPIO_CLK_ENABLE();

  /* configure GPIO for LCD reset pin */
  gpio.Pin   = LCD_RESET_PIN;
  gpio.Pull  = GPIO_NOPULL;
  gpio.Speed = GPIO_SPEED_FAST;
  gpio.Mode  = GPIO_MODE_OUTPUT_PP;
  HAL_GPIO_Init( LCD_RESET_GPIO_PORT, &gpio );

  /* apply hardware reset */
  HAL_GPIO_WritePin( LCD_RESET_GPIO_PORT, LCD_RESET_PIN, GPIO_PIN_RESET );
  HAL_Delay( 5 );   /* reset signal asserted during 5ms  */
  HAL_GPIO_WritePin( LCD_RESET_GPIO_PORT, LCD_RESET_PIN, GPIO_PIN_SET );
  HAL_Delay( 10 );  /* reset signal released during 10ms */
  HAL_GPIO_WritePin( LCD_RESET_GPIO_PORT, LCD_RESET_PIN, GPIO_PIN_RESET );
  HAL_Delay( 20 );  /* reset signal asserted during 20ms */
  HAL_GPIO_WritePin( LCD_RESET_GPIO_PORT, LCD_RESET_PIN, GPIO_PIN_SET );
  HAL_Delay( 10 );  /* reset signal released during 10ms */

  /* enable clock for LCD backlight control pin */
  // LCD_BL_CTRL_GPIO_CLK_ENABLE();

  /* configure GPIO for LCD backlight control pin */
  // gpio.Pin  = LCD_BL_CTRL_PIN;
  // gpio.Mode = GPIO_MODE_OUTPUT_PP;
  // HAL_GPIO_Init( LCD_BL_CTRL_GPIO_PORT, &gpio );

  /* switch backlight on */
  // HAL_GPIO_WritePin( LCD_BL_CTRL_GPIO_PORT, LCD_BL_CTRL_PIN, GPIO_PIN_SET );
}


/* helper function to set a command register value */
static void ILI9341_WriteReg( uint8_t aReg )
{
  *ILI9341_Cmnd = aReg;
}


/* helper function to read a data value */
static uint16_t ILI9341_ReadData( void )
{
  return *ILI9341_Data;
}


/*******************************************************************************
* FUNCTION:
*   ILI9341_Init
*
* DESCRIPTION:
*   The function initializes the FSMC hardware and all necessary GPIO in order
*   to reset and intialize the connected display hardware.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void ILI9341_Init( void )
{
  /* initialize FSMC hardware (16bit, 8080 interface) */
  FMC_BANK1_Init();

  /* perform reset of LCD */
  ILI9341_ResetDisplay();

  /* switch display off */
  ILI9341_WriteReg( ILI9341_DISPLAY_OFF );

  /* power control B */
  ILI9341_WriteReg( ILI9341_POWERB );
  ILI9341_WriteData( 0x00 );
  ILI9341_WriteData( 0xC1 ); // or 0x83 or 0x81 ???
  ILI9341_WriteData( 0x30 );

  /* power on sequence control */
  ILI9341_WriteReg( ILI9341_POWER_SEQ );
  ILI9341_WriteData( 0x64 );
  ILI9341_WriteData( 0x03 );
  ILI9341_WriteData( 0x12 );
  ILI9341_WriteData( 0x81 );

  /* driver timing control A */
  ILI9341_WriteReg( ILI9341_DTCA );
  ILI9341_WriteData( 0x85 );
  ILI9341_WriteData( 0x00 );  // or 0x01
  ILI9341_WriteData( 0x78 );  // or 0x79

  /* power control A */
  ILI9341_WriteReg( ILI9341_POWERA );
  ILI9341_WriteData( 0x39 );
  ILI9341_WriteData( 0x2C );
  ILI9341_WriteData( 0x00 );
  ILI9341_WriteData( 0x34 );
  ILI9341_WriteData( 0x02 );

  /* pump ratio control */
  ILI9341_WriteReg( ILI9341_PRC );
  ILI9341_WriteData( 0x20 );

  /* driver timing control B */
  ILI9341_WriteReg( ILI9341_DTCB );
  ILI9341_WriteData( 0x00 );
  ILI9341_WriteData( 0x00 );

  /* power control 1 */
  ILI9341_WriteReg( ILI9341_POWER1 );
  ILI9341_WriteData( 0x09 );    // = 3.3 V

  /* power control 2 */
  ILI9341_WriteReg( ILI9341_POWER2 );
  ILI9341_WriteData( 0x10 );

  /* VCOM 1 / 2 registers */
  ILI9341_WriteReg( ILI9341_VCOM1 );
  ILI9341_WriteData( 0x45 );
  ILI9341_WriteData( 0x15 );
  ILI9341_WriteReg( ILI9341_VCOM2 );
  ILI9341_WriteData( 0x90 );

  /* memory access control */
  ILI9341_WriteReg( ILI9341_MAC );
  ILI9341_WriteData( 0x48 ); // 0xC8 ???

  /* pixel format set */
  ILI9341_WriteReg( ILI9341_PIXEL_FORMAT );
  ILI9341_WriteData( 0x55 );

  /* frame rate */
  ILI9341_WriteReg( ILI9341_FRMCTR1 );
  ILI9341_WriteData( 0x00 );
  ILI9341_WriteData( 0x1B );

  /* gamma configuration */
  ILI9341_WriteReg( ILI9341_3GAMMA_EN );
  ILI9341_WriteData( 0x00 );

  ILI9341_WriteReg( ILI9341_GAMMA );
  ILI9341_WriteData( 0x01 );

  ILI9341_WriteReg( ILI9341_PGAMMA );
  ILI9341_WriteData( 0x0F );
  ILI9341_WriteData( 0x29 );
  ILI9341_WriteData( 0x24 );
  ILI9341_WriteData( 0x0C );
  ILI9341_WriteData( 0x0E );
  ILI9341_WriteData( 0x09 );
  ILI9341_WriteData( 0x4E );
  ILI9341_WriteData( 0x78 );
  ILI9341_WriteData( 0x3C );
  ILI9341_WriteData( 0x09 );
  ILI9341_WriteData( 0x13 );
  ILI9341_WriteData( 0x05 );
  ILI9341_WriteData( 0x17 );
  ILI9341_WriteData( 0x11 );
  ILI9341_WriteData( 0x00 );

  ILI9341_WriteReg( ILI9341_NGAMMA );
  ILI9341_WriteData( 0x00 );
  ILI9341_WriteData( 0x16 );
  ILI9341_WriteData( 0x1B );
  ILI9341_WriteData( 0x04 );
  ILI9341_WriteData( 0x11 );
  ILI9341_WriteData( 0x07 );
  ILI9341_WriteData( 0x31 );
  ILI9341_WriteData( 0x33 );
  ILI9341_WriteData( 0x42 );
  ILI9341_WriteData( 0x05 );
  ILI9341_WriteData( 0x0C );
  ILI9341_WriteData( 0x0A );
  ILI9341_WriteData( 0x28 );
  ILI9341_WriteData( 0x2F );
  ILI9341_WriteData( 0x0F );

  /* colomn address set */
  ILI9341_WriteReg( ILI9341_COLUMN_ADDR );
  ILI9341_WriteData( 0x00 );
  ILI9341_WriteData( 0x00 );
  ILI9341_WriteData( 0x00 );
  ILI9341_WriteData( 0xEF );

  /* page address set */
  ILI9341_WriteReg( ILI9341_PAGE_ADDR );
  ILI9341_WriteData( 0x00 );
  ILI9341_WriteData( 0x00 );
  ILI9341_WriteData( 0x01 );
  ILI9341_WriteData( 0x3F );

  /* entry mode set */
  ILI9341_WriteReg( ILI9341_ETMOD );
  ILI9341_WriteData( 0x07 );

  /* display function control set */
  ILI9341_WriteReg( ILI9341_DFC );
  ILI9341_WriteData( 0x0A );
  ILI9341_WriteData( 0x82 );
  ILI9341_WriteData( 0x27 );
  ILI9341_WriteData( 0x00 );

  /* wake up */
  ILI9341_WriteReg( ILI9341_SLEEP_OUT );
  HAL_Delay( 200 );

  /* switch display on */
  ILI9341_WriteReg( ILI9341_DISPLAY_ON );
  HAL_Delay( 200 );

  /* start writing to GRAM */
  ILI9341_WriteReg( ILI9341_GRAM );
}


/*******************************************************************************
* FUNCTION:
*   ILI9341_ReadID
*
* DESCRIPTION:
*   The function assumes a connected and intialized ILI9341 display and tries
*   to read its ID.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   If successful, the function returns the ID of the display - 0 otherwise.
*
*******************************************************************************/
uint16_t ILI9341_ReadID(void)
{
  uint16_t result;

  /* send command */
  ILI9341_WriteReg( ILI9341_READ_ID4 );

  /* read dummy data */
  ILI9341_ReadData();

  /* read register values */
  ILI9341_ReadData();
  result = (( ILI9341_ReadData() & 0xFF ) << 8 );
  result |= ( ILI9341_ReadData() & 0xFF );

  return result;
}


/*******************************************************************************
* FUNCTION:
*   ILI9341_SetDataPosition
*
* DESCRIPTION:
*   The function sets the destination position within the framebuffer of the
*   display according the given x/y position.
*
* ARGUMENTS:
*   aX       - Horizontal position for next write access.
*   aY       - Vertical position for next write access.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void ILI9341_SetDataPosition( uint16_t aX, uint16_t aY )
{
  /* colomn address set */
  ILI9341_WriteReg( ILI9341_COLUMN_ADDR );
  ILI9341_WriteData( aX >> 8 );
  ILI9341_WriteData( aX & 0xFF );
  ILI9341_WriteData(( DISPLAY_PIXEL_WIDTH - 1 ) >> 8 );
  ILI9341_WriteData(( DISPLAY_PIXEL_WIDTH - 1 ) & 0xFF );

  /* page address set */
  ILI9341_WriteReg( ILI9341_PAGE_ADDR );
  ILI9341_WriteData( aY >> 8 );
  ILI9341_WriteData( aY & 0xFF );
  ILI9341_WriteData(( DISPLAY_PIXEL_HEIGHT - 1 ) >> 8 );
  ILI9341_WriteData(( DISPLAY_PIXEL_HEIGHT - 1 ) & 0xFF );

  /* start writing to GRAM */
  ILI9341_WriteReg( ILI9341_GRAM );
}


/*******************************************************************************
* FUNCTION:
*   ILI9341_SetDataWindow
*
* DESCRIPTION:
*   The function sets the destination position and size within the framebuffer
*   of the display according the given rectangle.
*
* ARGUMENTS:
*   aX       - Horizontal position for next write access.
*   aY       - Vertical position for next write access.
*   aW       - Width of the data window in pixel.
*   aH       - Height of the data window in pixel.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void ILI9341_SetDataWindow( uint16_t aX, uint16_t aY, uint16_t aW, uint16_t aH )
{
  int xEnd = aX + aW - 1;
  int yEnd = aY + aH - 1;

  if ( xEnd >= DISPLAY_PIXEL_WIDTH )
    xEnd = DISPLAY_PIXEL_WIDTH - 1;
  if ( yEnd >= DISPLAY_PIXEL_HEIGHT )
    yEnd = DISPLAY_PIXEL_HEIGHT - 1;

  /* colomn address set */
  ILI9341_WriteReg( ILI9341_COLUMN_ADDR );
  ILI9341_WriteData( aX >> 8 );
  ILI9341_WriteData( aX & 0xFF );
  ILI9341_WriteData( xEnd >> 8 );
  ILI9341_WriteData( xEnd & 0xFF );

  /* page address set */
  ILI9341_WriteReg( ILI9341_PAGE_ADDR );
  ILI9341_WriteData( aY >> 8 );
  ILI9341_WriteData( aY & 0xFF );
  ILI9341_WriteData( yEnd >> 8 );
  ILI9341_WriteData( yEnd & 0xFF );

  /* start writing to GRAM */
  ILI9341_WriteReg( ILI9341_GRAM );
}


/*******************************************************************************
* FUNCTION:
*   ILI9341_WriteData
*
* DESCRIPTION:
*   Write a single data word to the ILI9341 display.
*
* ARGUMENTS:
*   aData    - 16 bit value to be sent to the ILI9341 display.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void ILI9341_WriteData( uint16_t aData )
{
  *ILI9341_Data = aData;
}


/*******************************************************************************
* FUNCTION:
*   ILI9341_WriteMultipleData
*
* DESCRIPTION:
*   Write a sequence of data words to the ILI9341 display.
*
* ARGUMENTS:
*   aData    - pointer to 16 bit values to be sent to the ILI9341 display.
*   aSize    - Number of data values to be sent.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void ILI9341_WriteMultipleData( uint16_t* aData, uint32_t aSize )
{
  while ( aSize-- )
    *ILI9341_Data = *aData++;
}


/* msy */

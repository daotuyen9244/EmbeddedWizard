/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is delivered "as is" and shows the usage of other software
* components. It is provided as an example software which is intended to be
* modified and extended according to particular requirements.
*
* TARA Systems hereby disclaims all warranties and conditions with regard to the
* software, including all implied warranties and conditions of merchantability
* and non-infringement of any third party IPR or other rights which may result
* from the use or the inability to use the software.
*
********************************************************************************
*
* DESCRIPTION:
*   This file contains the necessary initialization of the STMPE811 touch
*   controller and the necessary function to read the current touch position.
*   The data transfer is done by using the hardware I2C controller.
*
*   This module is just a template - adapt pin configuration and timing (!)
*   according your hardware layout and hardware constraints.
*   Adjust device parameters, initialization and filtering of the touch
*   coordinates according your touch screen and your needs.
*
*   This module is based on stmpe811.c from STMicroelectronics:
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2014 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
*
*******************************************************************************/

#include "stm32f4xx_hal.h"
#include "stmpe811_i2c.h"

/* simple calibration and filtering data */
#define X_MIN                           3850
#define X_MAX                           150
#define Y_MIN                           200
#define Y_MAX                           3850
#define CHANGE_XY                       0
#define NO_OF_SAMPLES                   4

#define TS_I2C_ADDRESS                  0x82

/* Chip IDs */
#define STMPE811_ID                     0x0811

/* Identification registers & System Control */
#define STMPE811_REG_CHP_ID_LSB         0x00
#define STMPE811_REG_CHP_ID_MSB         0x01
#define STMPE811_REG_ID_VER             0x02

/* Global interrupt Enable bit */
#define STMPE811_GIT_EN                 0x01

/* IO expander functionalities */
#define STMPE811_ADC_FCT                0x01
#define STMPE811_TS_FCT                 0x02
#define STMPE811_IO_FCT                 0x04
#define STMPE811_TEMPSENS_FCT           0x08

/* General Control Registers */
#define STMPE811_REG_SYS_CTRL1          0x03
#define STMPE811_REG_SYS_CTRL2          0x04
#define STMPE811_REG_SPI_CFG            0x08

/* Interrupt system Registers */
#define STMPE811_REG_INT_CTRL           0x09
#define STMPE811_REG_INT_EN             0x0A
#define STMPE811_REG_INT_STA            0x0B
#define STMPE811_REG_IO_INT_EN          0x0C
#define STMPE811_REG_IO_INT_STA         0x0D

/* IO Registers */
#define STMPE811_REG_IO_SET_PIN         0x10
#define STMPE811_REG_IO_CLR_PIN         0x11
#define STMPE811_REG_IO_MP_STA          0x12
#define STMPE811_REG_IO_DIR             0x13
#define STMPE811_REG_IO_ED              0x14
#define STMPE811_REG_IO_RE              0x15
#define STMPE811_REG_IO_FE              0x16
#define STMPE811_REG_IO_AF              0x17

/* ADC Registers */
#define STMPE811_REG_ADC_INT_EN         0x0E
#define STMPE811_REG_ADC_INT_STA        0x0F
#define STMPE811_REG_ADC_CTRL1          0x20
#define STMPE811_REG_ADC_CTRL2          0x21
#define STMPE811_REG_ADC_CAPT           0x22
#define STMPE811_REG_ADC_DATA_CH0       0x30
#define STMPE811_REG_ADC_DATA_CH1       0x32
#define STMPE811_REG_ADC_DATA_CH2       0x34
#define STMPE811_REG_ADC_DATA_CH3       0x36
#define STMPE811_REG_ADC_DATA_CH4       0x38
#define STMPE811_REG_ADC_DATA_CH5       0x3A
#define STMPE811_REG_ADC_DATA_CH6       0x3B
#define STMPE811_REG_ADC_DATA_CH7       0x3C

/* Touch Screen Registers */
#define STMPE811_REG_TSC_CTRL           0x40
#define STMPE811_REG_TSC_CFG            0x41
#define STMPE811_REG_WDM_TR_X           0x42
#define STMPE811_REG_WDM_TR_Y           0x44
#define STMPE811_REG_WDM_BL_X           0x46
#define STMPE811_REG_WDM_BL_Y           0x48
#define STMPE811_REG_FIFO_TH            0x4A
#define STMPE811_REG_FIFO_STA           0x4B
#define STMPE811_REG_FIFO_SIZE          0x4C
#define STMPE811_REG_TSC_DATA_X         0x4D
#define STMPE811_REG_TSC_DATA_Y         0x4F
#define STMPE811_REG_TSC_DATA_Z         0x51
#define STMPE811_REG_TSC_DATA_XYZ       0x52
#define STMPE811_REG_TSC_FRACT_XYZ      0x56
#define STMPE811_REG_TSC_DATA_INC       0x57
#define STMPE811_REG_TSC_DATA_NON_INC   0xD7
#define STMPE811_REG_TSC_I_DRIVE        0x58
#define STMPE811_REG_TSC_SHIELD         0x59

/* Touch Screen Pins definition */
#define STMPE811_TOUCH_YD               STMPE811_PIN_7
#define STMPE811_TOUCH_XD               STMPE811_PIN_6
#define STMPE811_TOUCH_YU               STMPE811_PIN_5
#define STMPE811_TOUCH_XU               STMPE811_PIN_4
#define STMPE811_TOUCH_IO_ALL           (uint32_t)(STMPE811_TOUCH_YD | STMPE811_TOUCH_XD | STMPE811_TOUCH_YU | STMPE811_TOUCH_XU)

/* IO Pins definition */
#define STMPE811_PIN_0                  0x01
#define STMPE811_PIN_1                  0x02
#define STMPE811_PIN_2                  0x04
#define STMPE811_PIN_3                  0x08
#define STMPE811_PIN_4                  0x10
#define STMPE811_PIN_5                  0x20
#define STMPE811_PIN_6                  0x40
#define STMPE811_PIN_7                  0x80
#define STMPE811_PIN_ALL                0xFF

/* IO Pins directions */
#define STMPE811_DIRECTION_IN           0x00
#define STMPE811_DIRECTION_OUT          0x01

/* IO IT types */
#define STMPE811_TYPE_LEVEL             0x00
#define STMPE811_TYPE_EDGE              0x02

/* IO IT polarity */
#define STMPE811_POLARITY_LOW           0x00
#define STMPE811_POLARITY_HIGH          0x04

/* IO Pin IT edge modes */
#define STMPE811_EDGE_FALLING           0x01
#define STMPE811_EDGE_RISING            0x02

/* TS registers masks */
#define STMPE811_TS_CTRL_ENABLE         0x01
#define STMPE811_TS_CTRL_STATUS         0x80


static uint16_t                         TsXBoundary, TsYBoundary;

/*############################### I2Cx #######################################*/
/* User can use this section to tailor I2Cx instance used and associated
   resources */
#define DISCOVERY_I2Cx                          I2C1
#define DISCOVERY_I2Cx_CLOCK_ENABLE()           __I2C1_CLK_ENABLE()
#define DISCOVERY_I2Cx_FORCE_RESET()            __I2C1_FORCE_RESET()
#define DISCOVERY_I2Cx_RELEASE_RESET()          __I2C1_RELEASE_RESET()
#define DISCOVERY_I2Cx_SDA_GPIO_CLK_ENABLE()    __GPIOB_CLK_ENABLE()
#define DISCOVERY_I2Cx_SCL_GPIO_CLK_ENABLE()    __GPIOB_CLK_ENABLE()
#define DISCOVERY_I2Cx_SDA_GPIO_CLK_DISABLE()   __GPIOB_CLK_DISABLE()

/* Definition for DISCO I2Cx Pins */
#define DISCOVERY_I2Cx_SCL_PIN                  GPIO_PIN_8
#define DISCOVERY_I2Cx_SCL_GPIO_PORT            GPIOB
#define DISCOVERY_I2Cx_SCL_SDA_AF               GPIO_AF4_I2C1
#define DISCOVERY_I2Cx_SDA_PIN                  GPIO_PIN_9
#define DISCOVERY_I2Cx_SDA_GPIO_PORT            GPIOB

/* Definition for IOE I2Cx's NVIC */
#define DISCOVERY_I2Cx_EV_IRQn                  I2C3_EV_IRQn
#define DISCOVERY_I2Cx_ER_IRQn                  I2C3_ER_IRQn

/* I2C clock speed configuration (in Hz)
  WARNING:
   Make sure that this define is not already declared in other files.
   It can be used in parallel by other modules. */
#ifndef BSP_I2C_SPEED
 #define BSP_I2C_SPEED                          100000
#endif /* BSP_I2C_SPEED */

#define I2Cx_TIMEOUT_MAX                        0x3000 /*<! The value of the maximal timeout for I2C waiting loops */

static uint32_t I2cxTimeout = I2Cx_TIMEOUT_MAX; /*<! Value of Timeout when I2C communication fails */

I2C_HandleTypeDef I2cHandle;

/* I2Cx bus function */
static void     I2Cx_Init(void);
static void     I2Cx_WriteData(uint8_t Addr, uint8_t Reg, uint8_t Value);
static uint8_t  I2Cx_ReadData(uint8_t Addr, uint8_t Reg);
static uint8_t  I2Cx_ReadDataBuffer(uint8_t Addr, uint8_t Reg, uint8_t *pBuffer, uint16_t Length);
static void     I2Cx_Error(void);
static void     I2Cx_MspInit(I2C_HandleTypeDef *hi2c);

static void     stmpe811_Init(uint16_t DeviceAddr);
static void     stmpe811_Reset(uint16_t DeviceAddr);
static uint16_t stmpe811_ReadID(uint16_t DeviceAddr);
static void     stmpe811_TS_Start(uint16_t DeviceAddr);
static uint8_t  stmpe811_TS_DetectTouch(uint16_t DeviceAddr);
static void     stmpe811_TS_GetXY(uint16_t DeviceAddr, uint16_t *X, uint16_t *Y);


/******************************* I2C Routines *********************************/

/**
  * @brief  I2Cx MSP Initialization
  * @param  hi2c: I2C handle
  */
static void I2Cx_MspInit(I2C_HandleTypeDef *hi2c)
{
  GPIO_InitTypeDef  GPIO_InitStruct;

  if (hi2c->Instance == DISCOVERY_I2Cx)
  {
    /* Configure the GPIOs ---------------------------------------------------*/
    /* Enable GPIO clock */
    DISCOVERY_I2Cx_SDA_GPIO_CLK_ENABLE();
    DISCOVERY_I2Cx_SCL_GPIO_CLK_ENABLE();

    /* Configure I2C Tx as alternate function  */
    GPIO_InitStruct.Pin       = DISCOVERY_I2Cx_SCL_PIN;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Speed     = GPIO_SPEED_FAST;
    GPIO_InitStruct.Alternate = DISCOVERY_I2Cx_SCL_SDA_AF;
    HAL_GPIO_Init(DISCOVERY_I2Cx_SCL_GPIO_PORT, &GPIO_InitStruct);

    /* Configure I2C Rx as alternate function  */
    GPIO_InitStruct.Pin = DISCOVERY_I2Cx_SDA_PIN;
    HAL_GPIO_Init(DISCOVERY_I2Cx_SDA_GPIO_PORT, &GPIO_InitStruct);


    /* Configure the Discovery I2Cx peripheral -------------------------------*/
    /* Enable I2C3 clock */
    DISCOVERY_I2Cx_CLOCK_ENABLE();

    /* Force the I2C Peripheral Clock Reset */
    DISCOVERY_I2Cx_FORCE_RESET();

    /* Release the I2C Peripheral Clock Reset */
    DISCOVERY_I2Cx_RELEASE_RESET();

    /* Enable and set Discovery I2Cx Interrupt to the highest priority */
    HAL_NVIC_SetPriority(DISCOVERY_I2Cx_EV_IRQn, 0x00, 0);
    HAL_NVIC_EnableIRQ(DISCOVERY_I2Cx_EV_IRQn);

    /* Enable and set Discovery I2Cx Interrupt to the highest priority */
    HAL_NVIC_SetPriority(DISCOVERY_I2Cx_ER_IRQn, 0x00, 0);
    HAL_NVIC_EnableIRQ(DISCOVERY_I2Cx_ER_IRQn);
  }
}

/**
  * @brief  I2Cx Bus initialization.
  */
static void I2Cx_Init(void)
{
  if(HAL_I2C_GetState(&I2cHandle) == HAL_I2C_STATE_RESET)
  {
    I2cHandle.Instance              = DISCOVERY_I2Cx;
    I2cHandle.Init.ClockSpeed       = BSP_I2C_SPEED;
    I2cHandle.Init.DutyCycle        = I2C_DUTYCYCLE_2;
    I2cHandle.Init.OwnAddress1      = 0;
    I2cHandle.Init.AddressingMode   = I2C_ADDRESSINGMODE_7BIT;
    I2cHandle.Init.DualAddressMode  = I2C_DUALADDRESS_DISABLED;
    I2cHandle.Init.OwnAddress2      = 0;
    I2cHandle.Init.GeneralCallMode  = I2C_GENERALCALL_DISABLED;
    I2cHandle.Init.NoStretchMode    = I2C_NOSTRETCH_DISABLED;

    /* Init the I2C */
    I2Cx_MspInit(&I2cHandle);
    HAL_I2C_Init(&I2cHandle);
  }
}

/**
  * @brief  Writes a value in a register of the device through BUS.
  * @param  Addr: Device address on BUS Bus.
  * @param  Reg: The target register address to write
  * @param  Value: The target register value to be written
  */
static void I2Cx_WriteData(uint8_t Addr, uint8_t Reg, uint8_t Value)
  {
  HAL_StatusTypeDef status = HAL_OK;

  status = HAL_I2C_Mem_Write(&I2cHandle, Addr, (uint16_t)Reg, I2C_MEMADD_SIZE_8BIT, &Value, 1, I2cxTimeout);

  /* Check the communication status */
  if(status != HAL_OK)
  {
    /* Re-Initialize the BUS */
    I2Cx_Error();
  }
}


/**
  * @brief  Reads a register of the device through BUS.
  * @param  Addr: Device address on BUS Bus.
  * @param  Reg: The target register address to write
  * @retval Data read at register address
  */
static uint8_t I2Cx_ReadData(uint8_t Addr, uint8_t Reg)
{
  HAL_StatusTypeDef status = HAL_OK;
  uint8_t value = 0;

  status = HAL_I2C_Mem_Read(&I2cHandle, Addr, Reg, I2C_MEMADD_SIZE_8BIT, &value, 1, I2cxTimeout);

  /* Check the communication status */
  if(status != HAL_OK)
  {
    /* Re-Initialize the BUS */
    I2Cx_Error();
  }
  return value;
}

/**
  * @brief  Reads multiple data on the BUS.
  * @param  Addr: I2C Address
  * @param  Reg: Reg Address
  * @param  pBuffer: pointer to read data buffer
  * @param  Length: length of the data
  * @retval 0 if no problems to read multiple data
  */
static uint8_t I2Cx_ReadDataBuffer(uint8_t Addr, uint8_t Reg, uint8_t *pBuffer, uint16_t Length)
{
  HAL_StatusTypeDef status = HAL_OK;

  status = HAL_I2C_Mem_Read(&I2cHandle, Addr, (uint16_t)Reg, I2C_MEMADD_SIZE_8BIT, pBuffer, Length, I2cxTimeout);

  /* Check the communication status */
  if(status == HAL_OK)
  {
    return 0;
  }
  else
  {
    /* Re-Initialize the BUS */
    I2Cx_Error();

    return 1;
  }
}

/**
  * @brief  I2Cx error treatment function
  */
static void I2Cx_Error(void)
{
  /* De-initialize the SPI communication BUS */
  HAL_I2C_DeInit(&I2cHandle);

  /* Re-Initialize the SPI communication BUS */
  I2Cx_Init();
}



/**
  * @brief  Initialize the stmpe811 and configure the needed hardware resources
  * @param  DeviceAddr: Device address on communication Bus.
  * @retval None
  */
static void stmpe811_Init(uint16_t DeviceAddr)
{
  /* Initialize IO BUS layer */
  I2Cx_Init();

  /* Generate stmpe811 Software reset */
  stmpe811_Reset(DeviceAddr);
}

/**
  * @brief  Reset the stmpe811 by Software.
  * @param  DeviceAddr: Device address on communication Bus.
  * @retval None
  */
static void stmpe811_Reset(uint16_t DeviceAddr)
{
  /* Power Down the stmpe811 */
  I2Cx_WriteData(DeviceAddr, STMPE811_REG_SYS_CTRL1, 2);

  /* Wait for a delay to ensure registers erasing */
  HAL_Delay(10);

  /* Power On the Codec after the power off => all registers are reinitialized */
  I2Cx_WriteData(DeviceAddr, STMPE811_REG_SYS_CTRL1, 0);

  /* Wait for a delay to ensure registers erasing */
  HAL_Delay(2);
}

/**
  * @brief  Read the stmpe811 IO Expander device ID.
  * @param  DeviceAddr: Device address on communication Bus.
  * @retval The Device ID (two bytes).
  */
static uint16_t stmpe811_ReadID(uint16_t DeviceAddr)
{
  /* Initialize IO BUS layer */
  I2Cx_Init();

  /* Return the device ID value */
  return ((I2Cx_ReadData(DeviceAddr, STMPE811_REG_CHP_ID_LSB) << 8) |\
          (I2Cx_ReadData(DeviceAddr, STMPE811_REG_CHP_ID_MSB)));
}


/**
  * @brief  Enable the AF for the selected IO pin(s).
  * @param  DeviceAddr: Device address on communication Bus.
  * @param  IO_Pin: The IO pin to be configured. This parameter could be any
  *         combination of the following values:
  *   @arg  STMPE811_PIN_x: Where x can be from 0 to 7.
  * @retval None
  */
static void stmpe811_IO_EnableAF(uint16_t DeviceAddr, uint32_t IO_Pin)
{
  uint8_t tmp = 0;

  /* Get the current register value */
  tmp = I2Cx_ReadData(DeviceAddr, STMPE811_REG_IO_AF);

  /* Enable the selected pins alternate function */
  tmp &= ~(uint8_t)IO_Pin;

  /* Write back the new register value */
  I2Cx_WriteData(DeviceAddr, STMPE811_REG_IO_AF, tmp);
}


/**
  * @brief  Configures the touch Screen Controller (Single point detection)
  * @param  DeviceAddr: Device address on communication Bus.
  * @retval None.
  */
static void stmpe811_TS_Start(uint16_t DeviceAddr)
{
  uint8_t mode;

  /* Get the current register value */
  mode = I2Cx_ReadData(DeviceAddr, STMPE811_REG_SYS_CTRL2);

  /* Set the Functionalities to be Enabled */
  mode &= ~(STMPE811_IO_FCT);

  /* Write the new register value */
  I2Cx_WriteData(DeviceAddr, STMPE811_REG_SYS_CTRL2, mode);

  /* Select TSC pins in TSC alternate mode */
  stmpe811_IO_EnableAF(DeviceAddr, STMPE811_TOUCH_IO_ALL);

  /* Set the Functionalities to be Enabled */
  mode &= ~(STMPE811_TS_FCT | STMPE811_ADC_FCT);

  /* Set the new register value */
  I2Cx_WriteData(DeviceAddr, STMPE811_REG_SYS_CTRL2, mode);

  /* Select Sample Time, bit number and ADC Reference */
  I2Cx_WriteData(DeviceAddr, STMPE811_REG_ADC_CTRL1, 0x49);

  /* Wait for 2 ms */
  HAL_Delay(2);

  /* Select the ADC clock speed: 3.25 MHz */
  I2Cx_WriteData(DeviceAddr, STMPE811_REG_ADC_CTRL2, 0x01);

  /* Select 2 nF filter capacitor */
  /* Configuration:
     - Touch average control    : 4 samples
     - Touch delay time         : 500 uS
     - Panel driver setting time: 500 uS
  */
  I2Cx_WriteData(DeviceAddr, STMPE811_REG_TSC_CFG, 0x9A);

  /* Configure the Touch FIFO threshold: single point reading */
  I2Cx_WriteData(DeviceAddr, STMPE811_REG_FIFO_TH, 0x01);

  /* Clear the FIFO memory content. */
  I2Cx_WriteData(DeviceAddr, STMPE811_REG_FIFO_STA, 0x01);

  /* Put the FIFO back into operation mode  */
  I2Cx_WriteData(DeviceAddr, STMPE811_REG_FIFO_STA, 0x00);

  /* Set the range and accuracy pf the pressure measurement (Z) :
     - Fractional part :7
     - Whole part      :1
  */
  I2Cx_WriteData(DeviceAddr, STMPE811_REG_TSC_FRACT_XYZ, 0x01);

  /* Set the driving capability (limit) of the device for TSC pins: 50mA */
  I2Cx_WriteData(DeviceAddr, STMPE811_REG_TSC_I_DRIVE, 0x01);

  /* Touch screen control configuration (enable TSC):
     - No window tracking index
     - XYZ acquisition mode
   */
  I2Cx_WriteData(DeviceAddr, STMPE811_REG_TSC_CTRL, 0x01);

  /*  Clear all the status pending bits if any */
  I2Cx_WriteData(DeviceAddr, STMPE811_REG_INT_STA, 0xFF);

  /* Wait for 2 ms delay */
  HAL_Delay(2);
}

/**
  * @brief  Return if there is touch detected or not.
  * @param  DeviceAddr: Device address on communication Bus.
  * @retval Touch detected state.
  */
static uint8_t stmpe811_TS_DetectTouch(uint16_t DeviceAddr)
{
  uint8_t state;
  uint8_t ret = 0;

  state = ((I2Cx_ReadData(DeviceAddr, STMPE811_REG_TSC_CTRL) & (uint8_t)STMPE811_TS_CTRL_STATUS) == (uint8_t)0x80);

  if(state > 0)
  {
    if(I2Cx_ReadData(DeviceAddr, STMPE811_REG_FIFO_SIZE) > 0)
    {
      ret = 1;
    }
  }
  else
  {
    /* Reset FIFO */
    I2Cx_WriteData(DeviceAddr, STMPE811_REG_FIFO_STA, 0x01);
    /* Enable the FIFO again */
    I2Cx_WriteData(DeviceAddr, STMPE811_REG_FIFO_STA, 0x00);
  }

  return ret;
}

/**
  * @brief  Get the touch screen X and Y positions values
  * @param  DeviceAddr: Device address on communication Bus.
  * @param  X: Pointer to X position value
  * @param  Y: Pointer to Y position value
  * @retval None.
  */
static void stmpe811_TS_GetXY(uint16_t DeviceAddr, uint16_t *X, uint16_t *Y)
{
  uint8_t  dataXYZ[4];
  uint32_t uldataXYZ;

  I2Cx_ReadDataBuffer(DeviceAddr, STMPE811_REG_TSC_DATA_NON_INC, dataXYZ, sizeof(dataXYZ)) ;

  /* Calculate positions values */
  uldataXYZ = (dataXYZ[0] << 24)|(dataXYZ[1] << 16)|(dataXYZ[2] << 8)|(dataXYZ[3] << 0);
  *X = (uldataXYZ >> 20) & 0x00000FFF;
  *Y = (uldataXYZ >>  8) & 0x00000FFF;

  /* Reset FIFO */
  I2Cx_WriteData(DeviceAddr, STMPE811_REG_FIFO_STA, 0x01);
  /* Enable the FIFO again */
  I2Cx_WriteData(DeviceAddr, STMPE811_REG_FIFO_STA, 0x00);
}


/*******************************************************************************
* FUNCTION:
*   STMPE811_Init
*
* DESCRIPTION:
*   The function initializes the I2C hardware and all necessary GPIO in order
*   to reset and intialize the connected touch controller.
*
* ARGUMENTS:
*   aW       - Width of the touch area in pixel.
*   aH       - Height of the touch area in pixel.
*
* RETURN VALUE:
*   If successful, returns != 0.
*
*******************************************************************************/
int STMPE811_Init( uint16_t aW, uint16_t aH )
{
  /* Initialize x and y positions boundaries */
  TsXBoundary = aW;
  TsYBoundary = aH;

  /* Read ID and verify if the IO expander is ready */
  if ( stmpe811_ReadID( TS_I2C_ADDRESS ) == STMPE811_ID )
  {
    /* Initialize the LL TS Driver */
    stmpe811_Init( TS_I2C_ADDRESS );
    stmpe811_TS_Start( TS_I2C_ADDRESS );
    return 1;
  }

  return 0;
}

/*******************************************************************************
* FUNCTION:
*   STMPE811_GetTouchState
*
* DESCRIPTION:
*   The function returns the current touch state and touch position.
*
* ARGUMENTS:
*   aState   - Pointer to structure to return state and position.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void STMPE811_GetTouchState( TS_StateTypeDef* aState )
{
  uint16_t xr, yr;
  int32_t x, y;
  static int32_t filterX[ NO_OF_SAMPLES ];
  static int32_t filterY[ NO_OF_SAMPLES ];
  int i;

  /* read current touch state */
  aState->TouchDetected = stmpe811_TS_DetectTouch( TS_I2C_ADDRESS );
  if( aState->TouchDetected )
  {
    stmpe811_TS_GetXY( TS_I2C_ADDRESS, &xr, &yr );

    // xprintf( "x = %d, y = %d\n", xr, yr );

    /* change x/y values if necessary */
    #if CHANGE_XY == 1
      uint16_t tmp = xr;
      xr = yr;
      yr = tmp;
    #endif

    /* convert touch pos into screen X-pos by using simple calibration constants */
    #if ( X_MAX > X_MIN )
      x = ((int32_t)( xr - X_MIN ) * TsXBoundary ) / ( X_MAX - X_MIN );
    #else
      x = ((int32_t)( X_MIN - xr ) * TsXBoundary ) / ( X_MIN - X_MAX );
    #endif

    /* convert touch pos into screen Y-pos by using simple calibration constants */
    #if ( Y_MAX > Y_MIN )
      y = ((int32_t)( yr - Y_MIN ) * TsYBoundary ) / ( Y_MAX - Y_MIN );
    #else
      y = ((int32_t)( Y_MIN - yr ) * TsYBoundary ) / ( Y_MIN - Y_MAX );
    #endif

    /* correct limits */
    if ( x < 0 ) x = 0;
    if ( y < 0 ) y = 0;
    if ( x >= TsXBoundary ) x = TsXBoundary - 1;
    if ( y >= TsYBoundary ) y = TsYBoundary - 1;

    /* take first touch value as filter start value */
    if (( filterX[ 0 ] < 0 ) || ( filterY[ 0 ] < 0 ))
    {
      /* fill entire array with start value */
      for ( i = 0; i < NO_OF_SAMPLES; i++ )
      {
        filterX[ i ] = x;
        filterY[ i ] = y;
      }
    }
    else
    {
      /* move content of filter array */
      for ( i = 0; i < NO_OF_SAMPLES - 1; i++ )
      {
        filterX[ i ] = filterX[ i + 1 ];
        filterY[ i ] = filterY[ i + 1 ];
      }
      /* store new position at the end of the array */
      filterX[ NO_OF_SAMPLES - 1 ] = x;
      filterY[ NO_OF_SAMPLES - 1 ] = y;
    }

    /* build an avarage value about all values */
    for ( i = 0; i < NO_OF_SAMPLES - 1; i++ )
    {
      x += filterX[ i ];
      y += filterY[ i ];
    }
    x /= NO_OF_SAMPLES;
    y /= NO_OF_SAMPLES;

    /* update the X position */
    aState->X = (uint16_t)x;

    /* update the Y position */
    aState->Y = (uint16_t)y;
  }
  else
  {
    /* sign the first filter value as invalid */
    filterX[ 0 ] = -1;
    filterY[ 0 ] = -1;
  }
}


/* msy */

/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is delivered "as is" and shows the usage of other software
* components. It is provided as an example software which is intended to be
* modified and extended according to particular requirements.
*
* TARA Systems hereby disclaims all warranties and conditions with regard to the
* software, including all implied warranties and conditions of merchantability
* and non-infringement of any third party IPR or other rights which may result
* from the use or the inability to use the software.
*
********************************************************************************
*
* DESCRIPTION:
*   This file contains the necessary initialization of the STMPE811 touch
*   controller and the necessary function to read the current touch position.
*   The data transfer is done by using the hardware I2C controller.
*
*   This module is just a template - adapt pin configuration and timing (!)
*   according your hardware layout and hardware constraints.
*   Adjust device parameters, initialization and filtering of the touch
*   coordinates according your touch screen and your needs.
*
*   This module is based on stmpe811.c from STMicroelectronics:
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2014 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
*
*******************************************************************************/

#ifndef STMPE811_I2C_H
#define STMPE811_I2C_H


#ifdef __cplusplus
  extern "C"
  {
#endif

typedef struct
{
  uint16_t TouchDetected;
  uint16_t X;
  uint16_t Y;
  uint16_t Z;
}TS_StateTypeDef;


/*******************************************************************************
* FUNCTION:
*   STMPE811_Init
*
* DESCRIPTION:
*   The function initializes the I2C hardware and all necessary GPIO in order
*   to reset and intialize the connected touch controller.
*
* ARGUMENTS:
*   aW       - Width of the touch area in pixel.
*   aH       - Height of the touch area in pixel.
*
* RETURN VALUE:
*   If successful, returns != 0.
*
*******************************************************************************/
int STMPE811_Init
(
  uint16_t                    aW,
  uint16_t                    aH
);


/*******************************************************************************
* FUNCTION:
*   STMPE811_GetTouchState
*
* DESCRIPTION:
*   The function returns the current touch state and touch position.
*
* ARGUMENTS:
*   aState   - Pointer to structure to return state and position.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void STMPE811_GetTouchState
(
  TS_StateTypeDef*            aState
);


#ifdef __cplusplus
}
#endif

#endif /* STMPE811_I2C_H */


/* msy */

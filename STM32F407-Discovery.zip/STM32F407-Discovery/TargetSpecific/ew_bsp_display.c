/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is delivered "as is" and shows the usage of other software
* components. It is provided as an example software which is intended to be
* modified and extended according to particular requirements.
*
* TARA Systems hereby disclaims all warranties and conditions with regard to the
* software, including all implied warranties and conditions of merchantability
* and non-infringement of any third party IPR or other rights which may result
* from the use or the inability to use the software.
*
********************************************************************************
*
* DESCRIPTION:
*   This file is part of the interface (glue layer) between an Embedded Wizard
*   generated UI application and the board support package (BSP) of a dedicated
*   target.
*   This template is responsible to initialize the display hardware of the board
*   and to provide the necessary access to update the display content.
*
*******************************************************************************/

#include "stm32f4xx_hal.h"
#include "stm32f4_discovery.h"

/* flags to choose one of the provided display drivers */
//#define USE_ILI9341
//#define USE_ILI9325
//#define USE_SSD1963
#define USE_SSD2119

#if defined USE_ILI9341

  #include "ili9341_16bit_fsmc.h"

  #define  DispDrvSetDataPosition       ILI9341_SetDataPosition
  #define  DispDrvSetDataWindow         ILI9341_SetDataWindow
  #define  DispDrvWriteData             ILI9341_WriteData
  #define  DispDrvWriteMultipleData     ILI9341_WriteMultipleData

#elif defined USE_ILI9325

  #include "ili9325_16bit_fsmc.h"

  #define  DispDrvSetDataPosition       ILI9325_SetDataPosition
  #define  DispDrvSetDataWindow         ILI9325_SetDataWindow
  #define  DispDrvWriteData             ILI9325_WriteData
  #define  DispDrvWriteMultipleData     ILI9325_WriteMultipleData

#elif defined USE_SSD1963

  #include "ssd1963_16bit_fsmc.h"

  #define  DispDrvSetDataPosition       SSD1963_SetDataPosition
  #define  DispDrvSetDataWindow         SSD1963_SetDataWindow
  #define  DispDrvWriteData             SSD1963_WriteData
  #define  DispDrvWriteMultipleData     SSD1963_WriteMultipleData

#elif defined USE_SSD2119

  #include "ssd2119_16bit_fsmc.h"

  #define  DispDrvSetDataPosition       SSD2119_SetDataPosition
  #define  DispDrvSetDataWindow         SSD2119_SetDataWindow
  #define  DispDrvWriteData             SSD2119_WriteData
  #define  DispDrvWriteMultipleData     SSD2119_WriteMultipleData

#endif

#include "ewrte.h"
#include "ewgfx.h"
#include "ewextgfx.h"
#include "ewgfxdefs.h"

#include "ew_bsp_display.h"

static void*                  FramebufferAddress = 0;
static int                    FramebufferWidth   = 0;
static int                    FramebufferHeight  = 0;

#if (( EW_FRAME_BUFFER_COLOR_FORMAT == EW_FRAME_BUFFER_COLOR_FORMAT_Index8 ) \
  || ( EW_FRAME_BUFFER_COLOR_FORMAT == EW_FRAME_BUFFER_COLOR_FORMAT_LumA44 ))
  static unsigned short      Clut[ 256 ];
#endif


/*
   For STM32F407 only the following framebuffer color formats are supported.

   The color format of the framebuffer has to correspond to color format of the
   Graphics Engine - otherwise the Graphics Engine cannot draw directly into
   this framebuffer, because the Graphics engine is prepared and optimized for
   one dedicated color format.

   The color format of the LCD / framebuffer can be defined within the makefile
   by setting the macro EW_FRAME_BUFFER_COLOR_FORMAT.
*/
#if (( EW_FRAME_BUFFER_COLOR_FORMAT != EW_FRAME_BUFFER_COLOR_FORMAT_Index8 ) \
  && ( EW_FRAME_BUFFER_COLOR_FORMAT != EW_FRAME_BUFFER_COLOR_FORMAT_LumA44 ) \
  && ( EW_FRAME_BUFFER_COLOR_FORMAT != EW_FRAME_BUFFER_COLOR_FORMAT_RGB565 ))
  #error The given FRAME_BUFFER_COLOR_FORMAT is not supported! Use RGB565, Index8 or LumA44!
#endif


/*******************************************************************************
* FUNCTION:
*   EwBspConfigDisplay
*
* DESCRIPTION:
*   Configures the display hardware.
*
* ARGUMENTS:
*   aWidth   - Width of the framebuffer in pixel.
*   aHeight  - Height of the framebuffer in pixel.
*   aAddress - Startaddress of the framebuffer.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void EwBspConfigDisplay( int aWidth, int aHeight, void* aAddress )
{
#if defined USE_ILI9341

  /* initialize ILI9341 driver... */
  ILI9341_Init();

  /* ...and try to receive expected ID */
  if ( ILI9341_ReadID() != ILI9341_ID )
    EwPrint( "EwBspConfigDisplay: Failed to initialize ILI9341 display driver...\n" );

#elif defined USE_ILI9325

  /* initialize ILI9325 driver... */
  ILI9325_Init();

  /* ...and try to receive expected ID */
  if ( ILI9325_ReadID() != ILI9325_ID )
    EwPrint( "EwBspConfigDisplay: Failed to initialize ILI9325 display driver...\n" );

#elif defined USE_SSD1963

  /* initialize SSD1963 driver... */
  SSD1963_Init();

  /* ...and try to receive expected ID */
  if ( SSD1963_ReadID() != SSD1963_ID )
    EwPrint( "EwBspConfigDisplay: Failed to initialize SSD1963 display driver...\n" );

#elif defined USE_SSD2119

  /* initialize SSD2119 driver... */
  SSD2119_Init();

  /* ...and try to receive expected ID */
  if ( SSD2119_ReadID() != SSD2119_ID )
    EwPrint( "EwBspConfigDisplay: Failed to initialize SSD2119 display driver...\n" );

#endif

  /* store the given parameters */
  FramebufferAddress = aAddress;
  FramebufferWidth   = aWidth;
  FramebufferHeight  = aHeight;
  
  /* satisfy the compiler */
  FramebufferAddress = FramebufferAddress;  
  FramebufferWidth   = FramebufferWidth;  
  FramebufferHeight  = FramebufferHeight;  
}


/*******************************************************************************
* FUNCTION:
*   EwBspUpdateDisplay
*
* DESCRIPTION:
*   Starts the transfer of the framebuffer content via FSMC to update the LCD.
*   The function returns after the update is finished.
*
* ARGUMENTS:
*   aX       - X-position of the update area within the framebuffer.
*   aY       - Y-position of the update area within the framebuffer.
*   aWidth   - Width of the update area within the framebuffer.
*   aHeight  - Height of the update area within the framebuffer.
*   aAddress - Address of the scratch pad buffer to update framebuffer.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void EwBspUpdateDisplay( int aX, int aY, int aWidth, int aHeight, void* aAddress )
{
  int x, y, w, h;

  /* rotate UI coordinates into physical coordinates */
  #if ( EW_SURFACE_ROTATION == 90 )

    x = FramebufferWidth - aY - aHeight;
    y = aX;
    w = aHeight;
    h = aWidth;

  #elif ( EW_SURFACE_ROTATION == 270 )

    x = aY;
    y = FramebufferHeight - aX - aWidth;
    w = aHeight;
    h = aWidth;

  #elif ( EW_SURFACE_ROTATION == 180 )

    x = FramebufferWidth - aX - aWidth;
    y = FramebufferHeight - aY - aHeight;
    w = aWidth;
    h = aHeight;

  #else

    x = aX;
    y = aY;
    w = aWidth;
    h = aHeight;

  #endif

  /* update display content depending on source color format */
  #if (( EW_FRAME_BUFFER_COLOR_FORMAT == EW_FRAME_BUFFER_COLOR_FORMAT_Index8 ) \
    || ( EW_FRAME_BUFFER_COLOR_FORMAT == EW_FRAME_BUFFER_COLOR_FORMAT_LumA44 ))

    register unsigned char* src = (unsigned char*)aAddress;
    register int dw;

    while ( h-- > 0 )
    {
      /* set cursor at beginning of current line */
      DispDrvSetDataPosition( x, y );
      dw = w;

      /* copy one line into LCD - and convert source color format via clut */
      while( dw-- )
        DispDrvWriteData( Clut[ *src++ ]);

      /* next line */
      y++;
    }

  #else

    unsigned short* src = (unsigned short*)aAddress;

    /* set rectangular address window and write entire pixel buffer */
    DispDrvSetDataWindow( x, y, w, h );
    DispDrvWriteMultipleData( src, w * h );

  #endif
}


/*******************************************************************************
* FUNCTION:
*   EwBspSetFramebufferAddress
*
* DESCRIPTION:
*   The function EwBspSetFramebufferAddress is called from the Graphics Engine
*   in order to change the currently active framebuffer address. If the display
*   is running in a double-buffering mode, the function is called after each
*   screen update.
*   Changing the framebuffer address should be synchronized with V-sync.
*   In case of double-buffering, the function has to wait and return after
*   the V-sync was detected.
*
* ARGUMENTS:
*   aAddress - New address of the framebuffer to be shown on the display.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void EwBspSetFramebufferAddress( unsigned long aAddress )
{
#if EW_USE_DOUBLE_BUFFER == 1

#else

  /* just store address for later display updates */
  FramebufferAddress = (void*)aAddress;

#endif
}


/*******************************************************************************
* FUNCTION:
*   EwBspSetFramebufferClut
*
* DESCRIPTION:
*   The function EwBspSetFramebufferClut is called from the Graphics Engine
*   in order to update the hardware CLUT of the current framebuffer.
*   The function is only called when the color format of the framebuffer is
*   Index8 or LumA44.
*
* ARGUMENTS:
*   aClut - Pointer to a color lookup table with 256 enries.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void EwBspSetFramebufferClut( unsigned long* aClut )
{
#if ( EW_FRAME_BUFFER_COLOR_FORMAT == EW_FRAME_BUFFER_COLOR_FORMAT_Index8 )

    /* create a color lookup table to update display with RGB565 color format */
    register int i;
    for ( i = 0; i < 256; i++ )
    {
      register unsigned long c = *aClut++;
      Clut[ i ] = (( c & 0x00F80000 ) >> 8 ) | (( c & 0x0000FC00 ) >> 5 ) | (( c & 0x000000F8 ) >> 3 );
    }

#elif ( EW_FRAME_BUFFER_COLOR_FORMAT == EW_FRAME_BUFFER_COLOR_FORMAT_LumA44 )

    /* create a color lookup table to update display with RGB565 color format */
    register int i;
    for ( i = 0; i < 256; i++ )
    {
      register unsigned long l = ( i & 0x0F ) | (( i & 0x0F ) << 4 );
      Clut[ i ] = (( l & 0xF8 ) << 8 ) | (( l & 0xFC ) << 3 ) | (( l & 0xF8 ) >> 3 );
    }

#else

  EwPrint( "EwBspSetFramebufferClut: Could not load CLUT!\n" );

#endif
}


/* msy */
